# CreatorHub - Equity Partnership Platform

CreatorHub is a fintech platform that allows content creators to become equity partners by purchasing shares and receiving monthly profit distributions.

## 🚀 Features

- **Share Purchase System** with Paystack payment integration
- **Dynamic Share Pricing** based on net profit performance
- **Multi-currency Support** (NGN, USD, EUR, GBP)
- **Shareholder Agreement** auto-generated as PDF after purchase
- **Admin Dashboard** with full management capabilities
- **Partner Dashboard** with portfolio tracking and gain/loss visibility
- **Webhook Support** for reliable payment processing
- **Audit Logging** on all sensitive operations

## 🛠 Tech Stack

- **Frontend**: React 19 + Vite + Tailwind + shadcn/ui
- **Backend**: Express + TypeScript + Drizzle ORM
- **Database**: PostgreSQL
- **Payments**: Paystack
- **Monorepo**: pnpm workspaces

## 📦 Project Structure

```
Asset-Linker/
├── artifacts/
│   ├── api-server/          # Backend API
│   ├── creatorhub/          # Frontend App
│   └── db/                  # Database schemas
├── pnpm-workspace.yaml
└── README.md
```

## 🔧 Environment Setup

### 1. Backend Environment Variables

Create `artifacts/api-server/.env`:

```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/creatorhub

# JWT
SESSION_SECRET=your-super-long-random-secret-here

# Paystack
PAYSTACK_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxxxxxxxxxx

# Server
PORT=3000
NODE_ENV=production
```

### 2. Frontend Environment Variables

Create `artifacts/creatorhub/.env`:

```env
VITE_PAYSTACK_PUBLIC_KEY=pk_test_xxxxxxxxxxxxxxxxxxxxxxxx
VITE_API_BASE_URL=http://localhost:3000
```

## 🏗 Installation & Running

### Prerequisites
- Node.js 20+
- pnpm
- PostgreSQL

### Setup Steps

```bash
# 1. Install dependencies
pnpm install

# 2. Setup database
cd artifacts/db
pnpm run push          # Push schema to database

# 3. Start Backend
cd ../api-server
pnpm run dev

# 4. Start Frontend (in another terminal)
cd ../creatorhub
pnpm run dev
```

## 🔐 Production Checklist

Before going live:

- [ ] Replace all test Paystack keys with live keys
- [ ] Set strong `SESSION_SECRET`
- [ ] Enable HTTPS
- [ ] Set up proper database backups
- [ ] Configure Paystack Webhook URL
- [ ] Set up monitoring & logging
- [ ] Review and test all financial flows
- [ ] Add rate limiting on all public endpoints
- [ ] Enable database transactions on critical paths

## 📌 Important Notes

- **6-Month Profit Lock**: New shareholders do not receive profit distributions for the first 6 months after platform launch.
- **Share Cap**: Only 300,000 shares are available for purchase out of 1,000,000 total.
- **Dynamic Pricing**: Share price increases based on company net profit performance.

## 📄 License

Proprietary - CreatorHub Ltd

---

**Built with ❤️ for content creators**
