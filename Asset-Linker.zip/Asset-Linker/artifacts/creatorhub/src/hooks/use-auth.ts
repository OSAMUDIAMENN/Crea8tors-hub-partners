import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useCallback } from "react";

export function useAuth() {
  const { data: authData, isLoading, error } = useGetMe({
    query: {
      retry: false,
    }
  });

  const queryClient = useQueryClient();

  const logout = useCallback(() => {
    localStorage.removeItem("authToken");
    queryClient.setQueryData(getGetMeQueryKey(), null);
    window.location.href = "/login";
  }, [queryClient]);

  const user = authData?.user;

  return {
    user,
    isLoading,
    isAdmin: user?.role === "admin",
    isPartner: user?.role === "partner",
    isAuthenticated: !!user,
    logout,
  };
}