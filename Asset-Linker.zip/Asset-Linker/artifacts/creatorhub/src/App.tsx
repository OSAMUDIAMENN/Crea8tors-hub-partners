import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import NotFound from "@/pages/not-found";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/layout/sidebar";
import { ProtectedRoute } from "@/components/protected-route";

// Pages
import Home from "@/pages/home";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import Payments from "@/pages/payments";
import AdminOverview from "@/pages/admin/index";
import AdminPartners from "@/pages/admin/partners";
import AdminProfits from "@/pages/admin/profits";
import AdminWithdrawals from "@/pages/admin/withdrawals";
import AdminKyc from "@/pages/admin/kyc";
import AdminInvitations from "@/pages/admin/invitations";
import AdminTransactions from "@/pages/admin/transactions";

const queryClient = new QueryClient();

function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <AppSidebar />
        <main className="flex-1 w-full bg-background border-l border-border/40 overflow-y-auto">
          {children}
        </main>
      </div>
    </SidebarProvider>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      
      <Route path="/dashboard">
        <ProtectedRoute requirePartner>
          <MainLayout>
            <Dashboard />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/payments">
        <ProtectedRoute requirePartner>
          <MainLayout>
            <Payments />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/admin">
        <ProtectedRoute requireAdmin>
          <MainLayout>
            <AdminOverview />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/admin/partners">
        <ProtectedRoute requireAdmin>
          <MainLayout>
            <AdminPartners />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/admin/profits">
        <ProtectedRoute requireAdmin>
          <MainLayout>
            <AdminProfits />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/admin/withdrawals">
        <ProtectedRoute requireAdmin>
          <MainLayout>
            <AdminWithdrawals />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/admin/kyc">
        <ProtectedRoute requireAdmin>
          <MainLayout>
            <AdminKyc />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/admin/payments">
        <ProtectedRoute requireAdmin>
          <MainLayout>
            <AdminPayments />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/admin/invitations">
        <ProtectedRoute requireAdmin>
          <MainLayout>
            <AdminInvitations />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/admin/transactions">
        <ProtectedRoute requireAdmin>
          <MainLayout>
            <AdminTransactions />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="dark">
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;