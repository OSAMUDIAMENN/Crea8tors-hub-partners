import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarFooter } from "@/components/ui/sidebar";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { Briefcase, LayoutDashboard, Users, TrendingUp, HandCoins, FileCheck, Link as LinkIcon, LogOut, FileText, CreditCard } from "lucide-react";

export function AppSidebar() {
  const { user, isAdmin, logout } = useAuth();
  const [location] = useLocation();

  return (
    <Sidebar variant="inset">
      <SidebarHeader className="border-b border-border/50 py-4 px-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-primary-foreground font-bold text-lg">
            C
          </div>
          <span className="font-semibold text-lg tracking-tight">CreatorHub</span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        {isAdmin ? (
          <SidebarGroup>
            <SidebarGroupLabel className="text-muted-foreground uppercase text-xs tracking-wider">Admin Portal</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/admin"}>
                    <Link href="/admin">
                      <LayoutDashboard className="w-4 h-4 mr-2" />
                      Overview
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/admin/partners"}>
                    <Link href="/admin/partners">
                      <Users className="w-4 h-4 mr-2" />
                      Partners
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/admin/profits"}>
                    <Link href="/admin/profits">
                      <TrendingUp className="w-4 h-4 mr-2" />
                      Profits
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/admin/withdrawals"}>
                    <Link href="/admin/withdrawals">
                      <HandCoins className="w-4 h-4 mr-2" />
                      Withdrawals
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/admin/transactions"}>
                    <Link href="/admin/transactions">
                      <FileText className="w-4 h-4 mr-2" />
                      Transactions
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/admin/kyc"}>
                    <Link href="/admin/kyc">
                      <FileCheck className="w-4 h-4 mr-2" />
                      KYC Review
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/admin/invitations"}>
                    <Link href="/admin/invitations">
                      <LinkIcon className="w-4 h-4 mr-2" />
                      Invitations
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ) : (
          <SidebarGroup>
            <SidebarGroupLabel className="text-muted-foreground uppercase text-xs tracking-wider">Partner Portal</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/dashboard"}>
                    <Link href="/dashboard">
                      <Briefcase className="w-4 h-4 mr-2" />
                      Portfolio
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/payments"}>
                    <Link href="/payments">
                      <CreditCard className="w-4 h-4 mr-2" />
                      Payments
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>
      <SidebarFooter className="border-t border-border/50 p-4">
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-sm font-medium">{user?.fullname}</span>
            <span className="text-xs text-muted-foreground capitalize">{user?.role}</span>
          </div>
          <button onClick={logout} className="p-2 text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-muted">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}