import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
  requirePartner?: boolean;
}

export function ProtectedRoute({ children, requireAdmin, requirePartner }: ProtectedRouteProps) {
  const { user, isLoading, isAdmin, isPartner, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        setLocation("/login");
      } else if (requireAdmin && !isAdmin) {
        setLocation("/dashboard");
      } else if (requirePartner && !isPartner) {
        setLocation("/admin");
      }
    }
  }, [isLoading, isAuthenticated, isAdmin, isPartner, requireAdmin, requirePartner, setLocation]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background text-foreground">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated || (requireAdmin && !isAdmin) || (requirePartner && !isPartner)) {
    return null;
  }

  return <>{children}</>;
}