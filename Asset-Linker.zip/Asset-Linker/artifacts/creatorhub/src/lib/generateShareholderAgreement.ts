import jsPDF from "jspdf";

interface AgreementData {
  shareholderName: string;
  shareholderEmail: string;
  sharesPurchased: number;
  pricePerShare: number;
  totalAmountPaid: number;
  ownershipPercentage: number;
  purchaseDate: string;
  transactionReference: string;
  currentTotalShares: number; // Usually 1,000,000
}

export function generateShareholderAgreement(data: AgreementData) {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 20;

  // Header
  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.text("CREATORHUB SHAREHOLDER AGREEMENT", pageWidth / 2, y, { align: "center" });
  y += 10;

  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  doc.text("This Shareholder Agreement (the “Agreement”) is entered into as of", pageWidth / 2, y, { align: "center" });
  y += 6;
  doc.text(data.purchaseDate, pageWidth / 2, y, { align: "center" });
  y += 12;

  // Parties
  doc.setFont("helvetica", "bold");
  doc.text("BETWEEN:", pageWidth / 2, y, { align: "center" });
  y += 8;

  doc.setFont("helvetica", "normal");
  doc.text("CreatorHub Ltd (the “Company”)", pageWidth / 2, y, { align: "center" });
  y += 6;
  doc.text("and", pageWidth / 2, y, { align: "center" });
  y += 6;
  doc.text(`${data.shareholderName} (“Shareholder” or “You”)`, pageWidth / 2, y, { align: "center" });
  y += 12;

  // Recitals
  doc.setFont("helvetica", "bold");
  doc.text("RECITALS", pageWidth / 2, y, { align: "center" });
  y += 8;

  doc.setFont("helvetica", "normal");
  const recitals = [
    "WHEREAS, the Company is a platform that enables content creators to become equity partners;",
    "WHEREAS, the Company has authorized a total of 1,000,000 shares;",
    "WHEREAS, the Shareholder desires to purchase shares in the Company;",
    "WHEREAS, the parties wish to set forth their agreement regarding the Shareholder’s investment.",
  ];

  recitals.forEach((text) => {
    const lines = doc.splitTextToSize(text, pageWidth - 40);
    doc.text(lines, 20, y);
    y += lines.length * 6 + 4;
  });

  y += 8;

  // Article 1: Purchase of Shares
  doc.setFont("helvetica", "bold");
  doc.text("ARTICLE 1 – PURCHASE OF SHARES", 20, y);
  y += 8;

  doc.setFont("helvetica", "normal");
  const article1 = [
    `1.1 The Shareholder agrees to purchase, and the Company agrees to sell, ${data.sharesPurchased} shares`,
    `    at a price of ₦${data.pricePerShare} per share, for a total consideration of ₦${data.totalAmountPaid}.`,
    "",
    `1.2 The Shareholder’s ownership percentage in the Company is ${data.ownershipPercentage.toFixed(4)}%.`,
    "",
    `1.3 The total authorized shares of the Company are 1,000,000. The Shareholder acknowledges`,
    `    that 300,000 shares are designated as available for sale to partners.`,
  ];

  article1.forEach((text) => {
    doc.text(text, 20, y);
    y += 6;
  });

  y += 6;

  // Article 2: Profit Distribution Lock
  doc.setFont("helvetica", "bold");
  doc.text("ARTICLE 2 – PROFIT DISTRIBUTION LOCK PERIOD", 20, y);
  y += 8;

  doc.setFont("helvetica", "normal");
  const article2 = [
    "2.1 The Shareholder agrees that no profit distributions shall be made to the Shareholder",
    "    for the first six (6) months following the official launch of the CreatorHub platform.",
    "",
    "2.2 This lock-up period is intended to allow the platform to stabilize operations and",
    "    generate sustainable profits before distributions begin.",
    "",
    "2.3 After the expiration of the six-month lock-up period, profit distributions shall be made",
    "    in accordance with the Shareholder’s ownership percentage, subject to the Company’s",
    "    distribution policy.",
  ];

  article2.forEach((text) => {
    doc.text(text, 20, y);
    y += 6;
  });

  y += 6;

  // Article 3: Rights of Shareholder
  doc.setFont("helvetica", "bold");
  doc.text("ARTICLE 3 – RIGHTS OF THE SHAREHOLDER", 20, y);
  y += 8;

  doc.setFont("helvetica", "normal");
  const article3 = [
    "3.1 The Shareholder shall have the right to receive profit distributions after the lock-up period,",
    "    proportional to their ownership percentage.",
    "",
    "3.2 The Shareholder shall have access to periodic financial reports and updates from the Company.",
  ];

  article3.forEach((text) => {
    doc.text(text, 20, y);
    y += 6;
  });

  y += 6;

  // Article 4: Transfer Restrictions
  doc.setFont("helvetica", "bold");
  doc.text("ARTICLE 4 – TRANSFER RESTRICTIONS", 20, y);
  y += 8;

  doc.setFont("helvetica", "normal");
  const article4 = [
    "4.1 The Shareholder may not sell, transfer, or assign their shares without the prior written",
    "    consent of the Company for a period of twelve (12) months from the date of purchase.",
    "",
    "4.2 Any transfer of shares must comply with applicable securities laws and the Company’s",
    "    right of first refusal.",
  ];

  article4.forEach((text) => {
    doc.text(text, 20, y);
    y += 6;
  });

  y += 6;

  // Article 5: Confidentiality
  doc.setFont("helvetica", "bold");
  doc.text("ARTICLE 5 – CONFIDENTIALITY", 20, y);
  y += 8;

  doc.setFont("helvetica", "normal");
  const article5 = [
    "5.1 The Shareholder agrees to keep confidential all non-public information received from the",
    "    Company regarding its business, operations, and financial condition.",
  ];

  article5.forEach((text) => {
    doc.text(text, 20, y);
    y += 6;
  });

  y += 6;

  // Article 6: Governing Law
  doc.setFont("helvetica", "bold");
  doc.text("ARTICLE 6 – GOVERNING LAW", 20, y);
  y += 8;

  doc.setFont("helvetica", "normal");
  const article6 = [
    "6.1 This Agreement shall be governed by and construed in accordance with the laws of the",
    "    Federal Republic of Nigeria.",
  ];

  article6.forEach((text) => {
    doc.text(text, 20, y);
    y += 6;
  });

  y += 10;

  // Signature Section
  doc.setFont("helvetica", "bold");
  doc.text("IN WITNESS WHEREOF, the parties have executed this Agreement as of the date first written above.", 20, y);
  y += 15;

  doc.setFont("helvetica", "normal");
  doc.text("FOR THE COMPANY:", 20, y);
  y += 15;
  doc.text("_______________________________", 20, y);
  y += 6;
  doc.text("Authorized Signatory", 20, y);
  y += 6;
  doc.text("CreatorHub Ltd", 20, y);

  y += 15;

  doc.text("FOR THE SHAREHOLDER:", 20, y);
  y += 15;
  doc.text("_______________________________", 20, y);
  y += 6;
  doc.text(data.shareholderName, 20, y);
  y += 6;
  doc.text(`Date: ${data.purchaseDate}`, 20, y);

  // Footer
  doc.setFontSize(9);
  doc.text(`Transaction Reference: ${data.transactionReference}`, 20, doc.internal.pageSize.getHeight() - 15);

  // Save the PDF
  doc.save(`CreatorHub_Shareholder_Agreement_${data.shareholderName.replace(/\s+/g, "_")}.pdf`);
}
