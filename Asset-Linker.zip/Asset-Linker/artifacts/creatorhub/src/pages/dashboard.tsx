import { useGetMyPartnerProfile, useListProfitDistributions, useListShareTransactions, useCreateWithdrawal, getGetMyPartnerProfileQueryKey, useListWithdrawals, getListWithdrawalsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useAuth } from "@/hooks/use-auth";
import { Badge } from "@/components/ui/badge";
import { Briefcase, TrendingUp, DollarSign } from "lucide-react";
import { format } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

const withdrawalSchema = z.object({
  amount: z.coerce.number().min(1, "Must withdraw at least $1"),
});

export default function Dashboard() {
  const { user } = useAuth();
  const { data: profile, isLoading } = useGetMyPartnerProfile({ query: { enabled: !!user } });
  const { data: distributions } = useListProfitDistributions();
  const { data: transactions } = useListShareTransactions();
  const { data: withdrawals } = useListWithdrawals();
  const createWithdrawal = useCreateWithdrawal();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof withdrawalSchema>>({
    resolver: zodResolver(withdrawalSchema),
    defaultValues: { amount: 0 },
  });

  const onWithdraw = (values: z.infer<typeof withdrawalSchema>) => {
    if (!profile) return;
    if (values.amount > (profile.pendingEarnings || 0)) {
      toast({ title: "Insufficient funds", description: "You cannot withdraw more than your pending earnings.", variant: "destructive" });
      return;
    }
    createWithdrawal.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Withdrawal requested" });
        queryClient.invalidateQueries({ queryKey: getGetMyPartnerProfileQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListWithdrawalsQueryKey() });
        form.reset();
      },
      onError: (err: any) => toast({ title: "Failed to request withdrawal", description: err.message, variant: "destructive" })
    });
  };
  
  if (isLoading || !profile) return <div className="p-8">Loading dashboard...</div>;

  const estimatedValue = profile.sharesOwned * 10; // TODO: use real current price

  // Buy Shares state
  const [buySharesAmount, setBuySharesAmount] = useState(0);
  const [isBuying, setIsBuying] = useState(false);
  const currentSharePrice = 10.10; // In real app, fetch from API
  const remainingShares = 300000 - (profile.sharesOwned || 0); // Simplified
  
  // Filter for my distributions and transactions
  const myDistributions = distributions?.filter(d => d.partnerId === profile.id) || [];
  const myTransactions = transactions?.filter(t => t.buyerId === profile.userId || t.sellerId === profile.userId) || [];
  const myWithdrawals = withdrawals?.filter(w => w.partnerId === profile.id) || [];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Partner Portfolio</h1>
          <p className="text-muted-foreground mt-1">Welcome back, {user?.fullname}</p>
        </div>
        <Badge variant={user?.kycStatus === 'approved' ? 'default' : 'secondary'} className="text-sm px-4 py-1">
          KYC Status: {user?.kycStatus}
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-card border-border/50 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Briefcase className="w-24 h-24" />
          </div>
          <CardHeader className="pb-2">
            <CardDescription className="uppercase tracking-wider font-medium text-xs">Total Ownership</CardDescription>
            <CardTitle className="text-4xl text-primary font-bold">{profile.ownershipPercentage.toFixed(4)}%</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">{profile.sharesOwned.toLocaleString()} Shares</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border/50 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <TrendingUp className="w-24 h-24" />
          </div>
          <CardHeader className="pb-2">
            <CardDescription className="uppercase tracking-wider font-medium text-xs">Estimated Value</CardDescription>
            <CardTitle className="text-4xl font-bold">${estimatedValue.toLocaleString()}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">Based on $10.00/share</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border/50 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <DollarSign className="w-24 h-24" />
          </div>
          <CardHeader className="pb-2">
            <CardDescription className="uppercase tracking-wider font-medium text-xs">Total Earnings</CardDescription>
            <CardTitle className="text-4xl font-bold text-green-500">${profile.totalEarnings.toLocaleString()}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center text-sm">
              <span className="text-muted-foreground">Pending:</span>
              <span className="font-medium">${profile.pendingEarnings?.toLocaleString() || '0'}</span>
            </div>
          </CardContent>
        </Card>

        {/* Buy Shares Section */}
        <Card className="bg-card border-border/50 shadow-sm">
          <CardHeader>
            <CardTitle>Buy Shares</CardTitle>
            <CardDescription>
              Current Price: <span className="font-semibold text-primary">${currentSharePrice}</span> &nbsp;|&nbsp; 
              Shares Remaining: <span className="font-semibold">{remainingShares.toLocaleString()}</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 items-end">
              <div className="flex-1">
                <label className="text-sm font-medium">Number of Shares</label>
                <Input 
                  type="number" 
                  min="1" 
                  max={remainingShares}
                  value={buySharesAmount || ''} 
                  onChange={(e) => setBuySharesAmount(parseInt(e.target.value) || 0)}
                  placeholder="Enter amount"
                />
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Total Cost</p>
                <p className="text-2xl font-bold">
                  ${(buySharesAmount * currentSharePrice).toFixed(2)}
                </p>
              </div>
              <Button 
                onClick={async () => {
                  if (buySharesAmount <= 0) return;
                  setIsBuying(true);
                  try {
                    const res = await fetch('/api/share-transactions/buy', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ shares: buySharesAmount })
                    });
                    const data = await res.json();
                    if (!res.ok) throw new Error(data.error);
                    
                    toast({ title: "Shares purchased successfully!" });
                    // Refresh data
                    window.location.reload(); 
                  } catch (err: any) {
                    toast({ title: "Purchase failed", description: err.message, variant: "destructive" });
                  } finally {
                    setIsBuying(false);
                  }
                }}
                disabled={isBuying || buySharesAmount <= 0 || buySharesAmount > remainingShares}
              >
                {isBuying ? "Processing..." : "Buy Shares"}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Max purchase: {remainingShares.toLocaleString()} shares (300,000 total limit)
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Share Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-right">Shares</TableHead>
                    <TableHead className="text-right">Price/Share</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {myTransactions.map(tx => (
                    <TableRow key={tx.id}>
                      <TableCell>{format(new Date(tx.createdAt), 'MMM d, yyyy')}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="uppercase text-[10px] tracking-wider">
                          {tx.transactionType}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {tx.buyerId === profile.userId ? '+' : '-'}{tx.shares.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right">${tx.pricePerShare.toFixed(2)}</TableCell>
                    </TableRow>
                  ))}
                  {myTransactions.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No transactions found.</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Profit Distributions</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Month</TableHead>
                    <TableHead>Currency</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {myDistributions.map(dist => (
                    <TableRow key={dist.id}>
                      <TableCell className="font-medium">{dist.profitMonth}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{dist.currency || "NGN"}</Badge>
                      </TableCell>
                      <TableCell>{format(new Date(dist.createdAt), 'MMM d, yyyy')}</TableCell>
                      <TableCell>
                        <Badge variant={dist.status === 'paid' ? 'default' : 'secondary'}>{dist.status}</Badge>
                      </TableCell>
                      <TableCell className="text-right text-green-500 font-medium">
                        +{dist.currency || "NGN"} {dist.amount.toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                  {myDistributions.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No distributions found.</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1 space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Request Withdrawal</CardTitle>
              <CardDescription>Available balance: ${profile.pendingEarnings?.toLocaleString() || '0'}</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onWithdraw)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Amount ($)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" max={profile.pendingEarnings || 0} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full" disabled={createWithdrawal.isPending || (profile.pendingEarnings || 0) <= 0}>
                    {createWithdrawal.isPending ? "Requesting..." : "Submit Request"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Withdrawal History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {myWithdrawals.map(w => (
                  <div key={w.id} className="flex justify-between items-center border-b border-border/50 pb-2 last:border-0">
                    <div>
                      <div className="font-medium">${w.amount.toLocaleString()}</div>
                      <div className="text-xs text-muted-foreground">{format(new Date(w.createdAt), 'MMM d, yyyy')}</div>
                    </div>
                    <Badge variant={w.status === 'approved' ? 'default' : w.status === 'rejected' ? 'destructive' : 'secondary'}>
                      {w.status}
                    </Badge>
                  </div>
                ))}
                {myWithdrawals.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">No withdrawal history.</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}