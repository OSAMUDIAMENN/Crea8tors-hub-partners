import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface AdminPayment {
  id: number;
  createdAt: string;
  buyerName: string;
  buyerEmail: string;
  shares: number;
  pricePerShare: number;
  totalAmount: number;
  transactionType: string;
}

export default function AdminPayments() {
  const { toast } = useToast();
  const [payments, setPayments] = useState<AdminPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPrice, setCurrentPrice] = useState(100);

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        const [txRes, marketRes] = await Promise.all([
          fetch("/api/share-transactions"),
          fetch("/api/share-transactions/market/stats"),
        ]);

        const txData = await txRes.json();
        const marketData = await marketRes.json();

        if (marketData.currentSharePrice) {
          setCurrentPrice(marketData.currentSharePrice);
        }

        // Filter only purchases and enrich with user data (simplified)
        const purchaseTxs = txData
          .filter((tx: any) => tx.transactionType === "purchase")
          .map((tx: any) => ({
            ...tx,
            totalAmount: tx.shares * tx.pricePerShare,
            buyerName: tx.buyerName || "Unknown",
            buyerEmail: tx.buyerEmail || "",
          }));

        setPayments(purchaseTxs);
      } catch (error) {
        toast({ title: "Failed to load payments", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };

    fetchPayments();
  }, []);

  const downloadReceipt = (payment: AdminPayment) => {
    // Simple PDF using browser print for now (can be upgraded to jsPDF)
    const content = `
      CreatorHub - Payment Receipt
      
      Transaction ID: ${payment.id}
      Date: ${new Date(payment.createdAt).toLocaleDateString()}
      Partner: ${payment.buyerName} (${payment.buyerEmail})
      Shares Purchased: ${payment.shares}
      Price per Share: ₦${payment.pricePerShare}
      Total Amount: ₦${payment.totalAmount}
      
      Thank you for investing with CreatorHub.
    `;

    const printWindow = window.open("", "_blank");
    if (printWindow) {
      printWindow.document.write(`<pre>${content}</pre>`);
      printWindow.document.close();
      printWindow.print();
    }
  };

  if (loading) return <div className="p-8">Loading all payments...</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">All Platform Payments</h1>
        <p className="text-muted-foreground mt-1">
          Overview of all share purchases across the platform
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Share Purchase Transactions ({payments.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Partner</TableHead>
                <TableHead>Shares</TableHead>
                <TableHead>Purchase Price</TableHead>
                <TableHead>Total Paid</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payments.length > 0 ? (
                payments.map((payment) => (
                  <TableRow key={payment.id}>
                    <TableCell>{new Date(payment.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{payment.buyerName}</div>
                        <div className="text-xs text-muted-foreground">{payment.buyerEmail}</div>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{payment.shares}</TableCell>
                    <TableCell>₦{payment.pricePerShare?.toFixed(2)}</TableCell>
                    <TableCell className="font-semibold">₦{payment.totalAmount?.toFixed(2)}</TableCell>
                    <TableCell>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => downloadReceipt(payment)}
                      >
                        Download Receipt
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                    No share purchases recorded yet.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
