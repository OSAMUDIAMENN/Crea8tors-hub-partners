import { useListShareTransactions, useCreateShareTransaction, useListPartners, getListShareTransactionsQueryKey, getListPartnersQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const txSchema = z.object({
  buyerId: z.coerce.number().optional().nullable(),
  sellerId: z.coerce.number().optional().nullable(),
  shares: z.coerce.number().min(1, "Must be at least 1 share"),
  pricePerShare: z.coerce.number().min(0.01, "Price must be positive"),
  transactionType: z.enum(["purchase", "transfer", "buyback"]),
});

export default function AdminTransactions() {
  const { data: transactions, isLoading: isTxLoading } = useListShareTransactions();
  const { data: partners } = useListPartners();
  const createTx = useCreateShareTransaction();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof txSchema>>({
    resolver: zodResolver(txSchema),
    defaultValues: { 
      buyerId: null,
      sellerId: null,
      shares: 100,
      pricePerShare: 10.00,
      transactionType: "purchase"
    },
  });

  const txType = form.watch("transactionType");

  const onSubmit = (values: z.infer<typeof txSchema>) => {
    // Clean up IDs based on type
    if (values.transactionType === "purchase") values.sellerId = null;
    if (values.transactionType === "buyback") values.buyerId = null;

    createTx.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Transaction recorded" });
        queryClient.invalidateQueries({ queryKey: getListShareTransactionsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListPartnersQueryKey() });
        form.reset();
      },
      onError: (err: any) => toast({ title: "Transaction failed", description: err.message, variant: "destructive" })
    });
  };

  if (isTxLoading) return <div className="p-8">Loading ledger...</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Share Ledger</h1>
        <p className="text-muted-foreground mt-1">Record purchases, transfers, and buybacks.</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        <Card className="xl:col-span-1 h-fit">
          <CardHeader>
            <CardTitle>New Transaction</CardTitle>
            <CardDescription>Record a share movement.</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="transactionType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="purchase">Company Sale (Purchase)</SelectItem>
                          <SelectItem value="transfer">Partner Transfer</SelectItem>
                          <SelectItem value="buyback">Company Buyback</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {txType !== "buyback" && (
                  <FormField
                    control={form.control}
                    name="buyerId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Buyer</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value?.toString() || ""}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select buyer partner" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {partners?.map(p => (
                              <SelectItem key={p.id} value={p.userId.toString()}>
                                {p.user.fullname} ({p.user.email})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                {txType !== "purchase" && (
                  <FormField
                    control={form.control}
                    name="sellerId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Seller</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value?.toString() || ""}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select seller partner" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {partners?.map(p => (
                              <SelectItem key={p.id} value={p.userId.toString()}>
                                {p.user.fullname} ({p.sharesOwned} shares)
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="shares"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Shares</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="pricePerShare"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price/Share ($)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button type="submit" className="w-full mt-4" disabled={createTx.isPending}>
                  {createTx.isPending ? "Recording..." : "Record Transaction"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Parties</TableHead>
                  <TableHead className="text-right">Shares</TableHead>
                  <TableHead className="text-right">Price</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions?.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell>{format(new Date(tx.createdAt), 'MMM d, yyyy')}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="uppercase text-[10px] tracking-wider">
                        {tx.transactionType}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {tx.transactionType === 'purchase' && (
                        <span>Company → <span className="font-medium text-primary">{tx.buyerName}</span></span>
                      )}
                      {tx.transactionType === 'buyback' && (
                        <span><span className="font-medium text-primary">{tx.sellerName}</span> → Company</span>
                      )}
                      {tx.transactionType === 'transfer' && (
                        <span><span className="font-medium">{tx.sellerName}</span> → <span className="font-medium text-primary">{tx.buyerName}</span></span>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-medium">{tx.shares.toLocaleString()}</TableCell>
                    <TableCell className="text-right">${tx.pricePerShare.toFixed(2)}</TableCell>
                    <TableCell className="text-right font-bold text-foreground">
                      ${(tx.shares * tx.pricePerShare).toLocaleString()}
                    </TableCell>
                  </TableRow>
                ))}
                {transactions?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No transactions recorded.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}