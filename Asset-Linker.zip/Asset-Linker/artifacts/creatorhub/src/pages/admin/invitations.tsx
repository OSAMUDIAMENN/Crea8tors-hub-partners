import { useListInvitations, useCreateInvitation, useRevokeInvitation, getListInvitationsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

const inviteSchema = z.object({
  email: z.string().email("Valid email is required"),
});

export default function AdminInvitations() {
  const { data: invitations, isLoading } = useListInvitations();
  const createInvite = useCreateInvitation();
  const revokeInvite = useRevokeInvitation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof inviteSchema>>({
    resolver: zodResolver(inviteSchema),
    defaultValues: { email: "" },
  });

  const onSubmit = (values: z.infer<typeof inviteSchema>) => {
    createInvite.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Invitation generated" });
        queryClient.invalidateQueries({ queryKey: getListInvitationsQueryKey() });
        form.reset();
      },
      onError: (err: any) => toast({ title: "Failed to create", description: err.message, variant: "destructive" })
    });
  };

  const handleRevoke = (id: number) => {
    revokeInvite.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Invitation revoked" });
        queryClient.invalidateQueries({ queryKey: getListInvitationsQueryKey() });
      },
      onError: (err: any) => toast({ title: "Failed to revoke", description: err.message, variant: "destructive" })
    });
  };

  const copyToClipboard = (token: string) => {
    const url = `${window.location.origin}/register?token=${token}`;
    navigator.clipboard.writeText(url);
    toast({ title: "Link copied to clipboard" });
  };

  if (isLoading) return <div className="p-8">Loading invitations...</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Invitations</h1>
        <p className="text-muted-foreground mt-1">Generate access tokens for new partners.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 h-fit">
          <CardHeader>
            <CardTitle>Generate Invite</CardTitle>
            <CardDescription>Create a new access token.</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input placeholder="partner@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={createInvite.isPending}>
                  {createInvite.isPending ? "Generating..." : "Generate Link"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Active Invitations</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Expires</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invitations?.map((invite) => (
                  <TableRow key={invite.id}>
                    <TableCell className="font-medium">{invite.email}</TableCell>
                    <TableCell>{format(new Date(invite.expiresAt), 'MMM d, yyyy')}</TableCell>
                    <TableCell>
                      <Badge variant={invite.used ? "secondary" : "default"}>
                        {invite.used ? "Used" : "Active"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {!invite.used && (
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" onClick={() => copyToClipboard(invite.token)}>Copy Link</Button>
                          <Button size="sm" variant="destructive" onClick={() => handleRevoke(invite.id)} disabled={revokeInvite.isPending}>Revoke</Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
                {invitations?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No invitations found.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}