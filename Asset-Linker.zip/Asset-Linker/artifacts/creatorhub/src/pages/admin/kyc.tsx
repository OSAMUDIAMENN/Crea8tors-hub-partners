import { useListKycDocuments, useUpdateKycStatus, getListKycDocumentsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";

export default function AdminKyc() {
  const { data: docs, isLoading } = useListKycDocuments();
  const updateStatus = useUpdateKycStatus();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleUpdate = (id: number, status: 'approved' | 'rejected') => {
    updateStatus.mutate({ id, data: { status } }, {
      onSuccess: () => {
        toast({ title: `KYC Document ${status}` });
        queryClient.invalidateQueries({ queryKey: getListKycDocumentsQueryKey() });
      },
      onError: (err: any) => toast({ title: "Failed to update", description: err.message, variant: "destructive" })
    });
  };

  if (isLoading) return <div className="p-8">Loading KYC submissions...</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">KYC Review</h1>
        <p className="text-muted-foreground mt-1">Verify partner identity documents.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Pending Submissions</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Partner</TableHead>
                <TableHead>Document Type</TableHead>
                <TableHead>Files</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {docs?.map((doc) => (
                <TableRow key={doc.id}>
                  <TableCell>{format(new Date(doc.createdAt), 'MMM d, yyyy')}</TableCell>
                  <TableCell className="font-medium">{doc.userName}</TableCell>
                  <TableCell className="capitalize">{doc.documentType}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      {doc.documentUrl && <a href={doc.documentUrl} target="_blank" rel="noreferrer" className="text-primary hover:underline text-sm">View ID</a>}
                      {doc.selfieUrl && <a href={doc.selfieUrl} target="_blank" rel="noreferrer" className="text-primary hover:underline text-sm">View Selfie</a>}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={doc.status === 'approved' ? 'default' : doc.status === 'rejected' ? 'destructive' : 'secondary'}>
                      {doc.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {doc.status === 'pending' && (
                      <div className="flex space-x-2">
                        <Button size="sm" variant="default" onClick={() => handleUpdate(doc.id, 'approved')}>Approve</Button>
                        <Button size="sm" variant="destructive" onClick={() => handleUpdate(doc.id, 'rejected')}>Reject</Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {docs?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No KYC submissions pending.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}