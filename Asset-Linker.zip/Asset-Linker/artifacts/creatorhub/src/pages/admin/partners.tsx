import { useListPartners, useUpdatePartnerStatus, getListPartnersQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

export default function AdminPartners() {
  const { data: partners, isLoading } = useListPartners();
  const updateStatus = useUpdatePartnerStatus();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleKycUpdate = (id: number, status: 'approved' | 'rejected') => {
    updateStatus.mutate({ id, data: { kycStatus: status } }, {
      onSuccess: () => {
        toast({ title: `KYC status updated to ${status}` });
        queryClient.invalidateQueries({ queryKey: getListPartnersQueryKey() });
      },
      onError: () => toast({ title: "Failed to update status", variant: "destructive" })
    });
  };

  if (isLoading) return <div className="p-8">Loading partners...</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Partners</h1>
        <p className="text-muted-foreground mt-1">Manage investor profiles and KYC status.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Investor Directory</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Partner</TableHead>
                <TableHead>Shares</TableHead>
                <TableHead>Ownership</TableHead>
                <TableHead>Total Earnings</TableHead>
                <TableHead>KYC Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {partners?.map((partner) => (
                <TableRow key={partner.id}>
                  <TableCell>
                    <div className="font-medium">{partner.user.fullname}</div>
                    <div className="text-sm text-muted-foreground">{partner.user.email}</div>
                  </TableCell>
                  <TableCell>{partner.sharesOwned.toLocaleString()}</TableCell>
                  <TableCell>{partner.ownershipPercentage.toFixed(4)}%</TableCell>
                  <TableCell>${partner.totalEarnings.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge variant={partner.user.kycStatus === 'approved' ? 'default' : partner.user.kycStatus === 'rejected' ? 'destructive' : 'secondary'}>
                      {partner.user.kycStatus}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {partner.user.kycStatus === 'pending' && (
                      <div className="flex space-x-2">
                        <Button size="sm" variant="default" onClick={() => handleKycUpdate(partner.id, 'approved')}>Approve</Button>
                        <Button size="sm" variant="destructive" onClick={() => handleKycUpdate(partner.id, 'rejected')}>Reject</Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {partners?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No partners found.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}