import { useListWithdrawals, useUpdateWithdrawalStatus, getListWithdrawalsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";

export default function AdminWithdrawals() {
  const { data: withdrawals, isLoading } = useListWithdrawals();
  const updateStatus = useUpdateWithdrawalStatus();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleUpdate = (id: number, status: 'approved' | 'rejected') => {
    updateStatus.mutate({ id, data: { status } }, {
      onSuccess: () => {
        toast({ title: `Withdrawal ${status}` });
        queryClient.invalidateQueries({ queryKey: getListWithdrawalsQueryKey() });
      },
      onError: (err: any) => toast({ title: "Failed to update", description: err.message, variant: "destructive" })
    });
  };

  if (isLoading) return <div className="p-8">Loading withdrawals...</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Withdrawal Requests</h1>
        <p className="text-muted-foreground mt-1">Review and process partner payout requests.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Requests</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Partner</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {withdrawals?.map((req) => (
                <TableRow key={req.id}>
                  <TableCell>{format(new Date(req.createdAt), 'MMM d, yyyy')}</TableCell>
                  <TableCell className="font-medium">{req.partnerName}</TableCell>
                  <TableCell>${req.amount.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge variant={req.status === 'approved' ? 'default' : req.status === 'rejected' ? 'destructive' : 'secondary'}>
                      {req.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {req.status === 'pending' && (
                      <div className="flex space-x-2">
                        <Button size="sm" variant="default" onClick={() => handleUpdate(req.id, 'approved')}>Approve</Button>
                        <Button size="sm" variant="destructive" onClick={() => handleUpdate(req.id, 'rejected')}>Reject</Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {withdrawals?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No withdrawal requests.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}