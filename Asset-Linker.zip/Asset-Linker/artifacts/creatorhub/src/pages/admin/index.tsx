import { useGetAdminOverview } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Briefcase, DollarSign, HandCoins, FileCheck, Building } from "lucide-react";
import { Link } from "wouter";

export default function AdminOverview() {
  const { data: stats, isLoading } = useGetAdminOverview();

  if (isLoading || !stats) return <div className="p-8">Loading overview...</div>;

  const summaryCards = [
    { title: "Total Investors", value: stats.totalInvestors.toLocaleString(), icon: Users, link: "/admin/partners" },
    { title: "Shares Sold", value: stats.sharesSold.toLocaleString(), icon: Briefcase, link: "/admin/transactions" },
    { title: "Shares Remaining", value: stats.sharesRemaining.toLocaleString(), icon: Building, link: "/admin/transactions" },
    { title: "Current Share Price", value: `$${(stats.currentSharePrice || 10).toFixed(2)}`, icon: DollarSign, link: "/admin/profits" },
    { title: "Capital Raised", value: `$${stats.totalCapitalRaised.toLocaleString()}`, icon: DollarSign, link: "/admin/transactions" },
    { title: "Pending Withdrawals", value: stats.pendingWithdrawals.toLocaleString(), icon: HandCoins, link: "/admin/withdrawals", highlight: stats.pendingWithdrawals > 0 },
    { title: "Pending KYC", value: stats.pendingKyc.toLocaleString(), icon: FileCheck, link: "/admin/kyc", highlight: stats.pendingKyc > 0 },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Admin Overview</h1>
        <p className="text-muted-foreground mt-1">Platform performance and pending actions.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {summaryCards.map((card, i) => (
          <Link key={i} href={card.link}>
            <Card className={`bg-card border-border/50 shadow-sm hover:border-primary/50 transition-colors cursor-pointer relative overflow-hidden ${card.highlight ? 'border-primary/50' : ''}`}>
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <card.icon className="w-16 h-16" />
              </div>
              <CardHeader className="pb-2">
                <CardDescription className="uppercase tracking-wider font-medium text-xs">{card.title}</CardDescription>
                <CardTitle className="text-3xl font-bold">{card.value}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-primary group-hover:underline">View Details →</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}