import { useListMonthlyProfits, useCreateMonthlyProfit, useDistributeProfit, getListMonthlyProfitsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useState } from "react";

const profitSchema = z.object({
  month: z.string().min(1, "Month is required"),
  totalProfit: z.coerce.number().min(0, "Must be positive"),
  distributableProfit: z.coerce.number().min(0, "Must be positive"),
  currency: z.string().regex(/^[A-Z]{3}$/, "Must be 3-letter ISO code (e.g. USD)").default("USD"),
});

export default function AdminProfits() {
  const { data: profits, isLoading } = useListMonthlyProfits();
  const createProfit = useCreateMonthlyProfit();
  const distributeProfit = useDistributeProfit();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingProfit, setEditingProfit] = useState<any>(null);
  const [newCurrency, setNewCurrency] = useState("NGN");

  const form = useForm<z.infer<typeof profitSchema>>({
    resolver: zodResolver(profitSchema),
    defaultValues: { month: "", totalProfit: 0, distributableProfit: 0, currency: "NGN" },
  });

  const onSubmit = (values: z.infer<typeof profitSchema>) => {
    createProfit.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Profit record created" });
        queryClient.invalidateQueries({ queryKey: getListMonthlyProfitsQueryKey() });
        form.reset({ currency: "NGN" }); // keep default currency
      },
      onError: (err: any) => toast({ title: "Failed to create", description: err.message, variant: "destructive" })
    });
  };

  const handleDistribute = (id: number) => {
    distributeProfit.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Profits distributed successfully" });
        queryClient.invalidateQueries({ queryKey: getListMonthlyProfitsQueryKey() });
      },
      onError: (err: any) => toast({ title: "Failed to distribute", description: err.message, variant: "destructive" })
    });
  };

  const handleEditCurrency = (profit: any) => {
    setEditingProfit(profit);
    setNewCurrency(profit.currency || "NGN");
    setEditDialogOpen(true);
  };

  const saveCurrencyChange = async () => {
    if (!editingProfit) return;

    try {
      const res = await fetch(`/api/monthly-profits/${editingProfit.id}/currency`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currency: newCurrency }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to update currency");
      }

      toast({ title: "Currency updated successfully" });
      queryClient.invalidateQueries({ queryKey: getListMonthlyProfitsQueryKey() });
      setEditDialogOpen(false);
      setEditingProfit(null);
    } catch (err: any) {
      toast({ title: "Failed to update currency", description: err.message, variant: "destructive" });
    }
  };

  if (isLoading) return <div className="p-8">Loading profits...</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Profits Management</h1>
        <p className="text-muted-foreground mt-1">Record monthly profits and distribute to partners.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Record Profit</CardTitle>
            <CardDescription>Add new monthly profit data.</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="month"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Month (YYYY-MM)</FormLabel>
                      <FormControl>
                        <Input placeholder="2023-10" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="totalProfit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Total Profit ($)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="distributableProfit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Distributable Profit ($)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="currency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Currency</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select currency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="NGN">NGN — Nigerian Naira</SelectItem>
                          <SelectItem value="USD">USD — US Dollar</SelectItem>
                          <SelectItem value="EUR">EUR — Euro</SelectItem>
                          <SelectItem value="GBP">GBP — British Pound</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={createProfit.isPending}>
                  {createProfit.isPending ? "Saving..." : "Save Record"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Profit History</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Month</TableHead>
                  <TableHead>Currency</TableHead>
                  <TableHead>Total Profit</TableHead>
                  <TableHead>Distributable</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {profits?.map((profit) => (
                  <TableRow key={profit.id}>
                    <TableCell className="font-medium">{profit.month}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{profit.currency || "USD"}</Badge>
                    </TableCell>
                    <TableCell>${profit.totalProfit.toLocaleString()}</TableCell>
                    <TableCell>${profit.distributableProfit.toLocaleString()}</TableCell>
                    <TableCell>
                      <Badge variant={profit.distributed ? "default" : "secondary"}>
                        {profit.distributed ? "Distributed" : "Pending"}
                      </Badge>
                    </TableCell>
                    <TableCell className="flex gap-2">
                      {!profit.distributed && (
                        <>
                          <Button size="sm" onClick={() => handleDistribute(profit.id)} disabled={distributeProfit.isPending}>
                            Distribute
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            onClick={() => handleEditCurrency(profit)}
                          >
                            Edit Currency
                          </Button>
                        </>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
                {profits?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No profit records found.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Edit Currency Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Currency</DialogTitle>
            <DialogDescription>
              Update the currency for profit record <strong>{editingProfit?.month}</strong>. 
              This can only be done before distribution.
            </DialogDescription>
          </DialogHeader>

          <div className="py-4">
            <Select value={newCurrency} onValueChange={setNewCurrency}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="NGN">NGN — Nigerian Naira</SelectItem>
                <SelectItem value="USD">USD — US Dollar</SelectItem>
                <SelectItem value="EUR">EUR — Euro</SelectItem>
                <SelectItem value="GBP">GBP — British Pound</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={saveCurrencyChange}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
