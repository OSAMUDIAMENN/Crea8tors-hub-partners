import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface PaymentTransaction {
  id: number;
  createdAt: string;
  shares: number;
  pricePerShare: number;
  transactionType: string;
  currentValue?: number;
  gainLoss?: number;
  gainLossPercent?: number;
}

export default function PaymentsHistory() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [transactions, setTransactions] = useState<PaymentTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPrice, setCurrentPrice] = useState(100);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch transactions
        const txRes = await fetch("/api/share-transactions");
        const txData = await txRes.json();

        // Fetch current market price
        const marketRes = await fetch("/api/share-transactions/market/stats");
        const marketData = await marketRes.json();

        if (marketData.currentSharePrice) {
          setCurrentPrice(marketData.currentSharePrice);
        }

        // Filter only this user's purchases
        const myPurchases = txData
          .filter((tx: any) => tx.buyerId === user?.id && tx.transactionType === "purchase")
          .map((tx: any) => {
            const currentValue = tx.shares * currentPrice;
            const purchaseValue = tx.shares * tx.pricePerShare;
            const gainLoss = currentValue - purchaseValue;
            const gainLossPercent = purchaseValue > 0 ? (gainLoss / purchaseValue) * 100 : 0;

            return {
              ...tx,
              currentValue,
              gainLoss,
              gainLossPercent,
            };
          });

        setTransactions(myPurchases);
      } catch (error) {
        toast({ title: "Failed to load payment history", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchData();
    }
  }, [user, currentPrice]);

  if (loading) {
    return <div className="p-8">Loading payment history...</div>;
  }

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Payment History</h1>
        <p className="text-muted-foreground mt-1">
          View all your share purchases and investment performance
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Share Purchases</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Shares</TableHead>
                <TableHead>Purchase Price</TableHead>
                <TableHead>Amount Paid</TableHead>
                <TableHead>Current Value</TableHead>
                <TableHead>Gain / Loss</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.length > 0 ? (
                transactions.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell>
                      {new Date(tx.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="font-medium">{tx.shares}</TableCell>
                    <TableCell>₦{tx.pricePerShare?.toFixed(2)}</TableCell>
                    <TableCell>
                      ₦{(tx.shares * tx.pricePerShare).toFixed(2)}
                    </TableCell>
                    <TableCell>
                      ₦{tx.currentValue?.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      <div className={tx.gainLoss && tx.gainLoss >= 0 ? "text-green-600" : "text-red-600"}>
                        {tx.gainLoss && tx.gainLoss >= 0 ? "+" : ""}
                        ₦{tx.gainLoss?.toFixed(2)}
                        <span className="text-xs ml-1">
                          ({tx.gainLossPercent && tx.gainLossPercent >= 0 ? "+" : ""}
                          {tx.gainLossPercent?.toFixed(1)}%)
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="default">Completed</Badge>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    No share purchases yet. Start investing from your dashboard!
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="text-sm text-muted-foreground">
        Note: Values are calculated using the current share price of ₦{currentPrice}.
      </div>
    </div>
  );
}
