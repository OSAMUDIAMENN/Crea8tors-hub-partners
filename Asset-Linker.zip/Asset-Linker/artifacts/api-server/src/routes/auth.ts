import { Router, Request, Response, NextFunction } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable, partnersTable, invitationsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { signToken, requireAuth } from "../lib/auth";

const router = Router();

// Simple in-memory rate limiter (no extra deps) - Critical security fix
const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

function createRateLimiter(maxRequests: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.socket.remoteAddress || "unknown";
    const key = `${ip}:${req.path}`;
    const now = Date.now();
    
    const record = rateLimitStore.get(key);
    
    if (!record || now > record.resetTime) {
      rateLimitStore.set(key, { count: 1, resetTime: now + windowMs });
      return next();
    }
    
    if (record.count >= maxRequests) {
      res.status(429).json({ error: "Too many requests, please try again later" });
      return;
    }
    
    record.count++;
    next();
  };
}

const loginRateLimit = createRateLimiter(10, 15 * 60 * 1000); // 10 attempts per 15 min
const registerRateLimit = createRateLimiter(5, 60 * 60 * 1000); // 5 registrations per hour

function formatUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    fullname: user.fullname,
    email: user.email,
    role: user.role,
    kycStatus: user.kycStatus,
    createdAt: user.createdAt.toISOString(),
  };
}

router.post("/auth/register", registerRateLimit, async (req, res): Promise<void> => {
  const { fullname, email, password, invitationToken } = req.body;

  if (!fullname || !email || !password) {
    res.status(400).json({ error: "fullname, email, and password are required" });
    return;
  }
  // Basic email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    res.status(400).json({ error: "Invalid email format" });
    return;
  }
  // Stronger password policy (High fix)
  if (password.length < 12) {
    res.status(400).json({ error: "Password must be at least 12 characters" });
    return;
  }
  if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[0-9]/.test(password)) {
    res.status(400).json({ error: "Password must contain uppercase, lowercase, and a number" });
    return;
  }

  const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (existing) {
    res.status(400).json({ error: "Email already registered" });
    return;
  }

  if (invitationToken) {
    const [inv] = await db.select().from(invitationsTable).where(
      and(eq(invitationsTable.token, invitationToken), eq(invitationsTable.used, false))
    );
    if (!inv) {
      res.status(400).json({ error: "Invalid or expired invitation token" });
      return;
    }
    if (inv.expiresAt < new Date()) {
      res.status(400).json({ error: "Invitation has expired" });
      return;
    }
    await db.update(invitationsTable).set({ used: true }).where(eq(invitationsTable.id, inv.id));
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const [user] = await db.insert(usersTable).values({ fullname, email, passwordHash, role: "partner", kycStatus: "pending" }).returning();

  await db.insert(partnersTable).values({ userId: user.id, sharesOwned: 0, ownershipPercentage: "0", totalEarnings: "0" });

  const token = signToken({ userId: user.id, role: user.role });
  res.status(201).json({ user: formatUser(user), token });
});

router.post("/auth/login", loginRateLimit, async (req, res): Promise<void> => {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({ error: "Email and password are required" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (!user) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const token = signToken({ userId: user.id, role: user.role });
  res.json({ user: formatUser(user), token });
});

router.post("/auth/logout", async (_req, res): Promise<void> => {
  res.json({ success: true });
});

router.get("/auth/me", requireAuth, async (req, res): Promise<void> => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!));
  if (!user) {
    res.status(401).json({ error: "User not found" });
    return;
  }
  res.json({ user: formatUser(user), token: null });
});

export default router;
