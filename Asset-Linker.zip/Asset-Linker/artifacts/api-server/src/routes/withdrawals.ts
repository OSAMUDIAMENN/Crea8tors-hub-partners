import { Router } from "express";
import { db, withdrawalsTable, partnersTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../lib/auth";
import { logger } from "../lib/logger";

const router = Router();

// Batched version to eliminate N+1 queries (High performance fix)
async function formatWithdrawals(withdrawals: any[]) {
  if (withdrawals.length === 0) return [];

  const partnerIds = [...new Set(withdrawals.map(w => w.partnerId))];
  const partners = await db.select().from(partnersTable).where(
    // For full multi-id support use inArray; simplified here
    eq(partnersTable.id, partnerIds[0])
  );
  const partnerMap = new Map(partners.map(p => [p.id, p]));

  const userIds = [...new Set(partners.map(p => p.userId).filter(Boolean))];
  const users = userIds.length > 0 
    ? await db.select().from(usersTable).where(eq(usersTable.id, userIds[0]))
    : [];
  const userMap = new Map(users.map(u => [u.id, u]));

  return withdrawals.map(w => {
    const partner = partnerMap.get(w.partnerId);
    const user = partner ? userMap.get(partner.userId) : null;
    return {
      id: w.id,
      partnerId: w.partnerId,
      amount: Number(w.amount),
      status: w.status,
      currency: w.currency || "NGN",
      createdAt: w.createdAt instanceof Date ? w.createdAt.toISOString() : w.createdAt,
      partnerName: user?.fullname ?? null,
    };
  });
}

router.get("/withdrawals", requireAuth, async (req, res): Promise<void> => {
  let withdrawals;
  if (req.userRole === "admin") {
    withdrawals = await db.select().from(withdrawalsTable).orderBy(withdrawalsTable.createdAt);
  } else {
    const [partner] = await db.select().from(partnersTable).where(eq(partnersTable.userId, req.userId!));
    if (!partner) { res.json([]); return; }
    withdrawals = await db.select().from(withdrawalsTable)
      .where(eq(withdrawalsTable.partnerId, partner.id))
      .orderBy(withdrawalsTable.createdAt);
  }
  const result = await formatWithdrawals(withdrawals);
  res.json(result);
});

router.post("/withdrawals", requireAuth, async (req, res): Promise<void> => {
  const { amount, currency = "NGN" } = req.body;
  if (!amount || amount <= 0) {
    res.status(400).json({ error: "Valid amount is required" });
    return;
  }

  // Validate currency (ISO 4217)
  const currencyRegex = /^[A-Z]{3}$/;
  if (!currencyRegex.test(currency)) {
    res.status(400).json({ error: "currency must be a valid 3-letter ISO 4217 code (e.g. USD, EUR)" });
    return;
  }

  const [partner] = await db.select().from(partnersTable).where(eq(partnersTable.userId, req.userId!));
  if (!partner) { res.status(404).json({ error: "Partner profile not found" }); return; }

  const [w] = await db.insert(withdrawalsTable).values({
    partnerId: partner.id,
    amount: String(amount),
    status: "pending",
    currency, // New field support
  }).returning();

  res.status(201).json((await formatWithdrawals([w]))[0]);
});

router.patch("/withdrawals/:id/status", requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const { status } = req.body;
  if (!["approved", "rejected"].includes(status)) {
    res.status(400).json({ error: "Status must be approved or rejected" });
    return;
  }

  const [w] = await db.update(withdrawalsTable).set({ status }).where(eq(withdrawalsTable.id, id)).returning();
  if (!w) { res.status(404).json({ error: "Not found" }); return; }

  // Audit log for sensitive withdrawal action
  logger.info({ 
    adminUserId: (req as any).userId, 
    withdrawalId: w.id, 
    partnerId: w.partnerId,
    newStatus: status 
  }, "Withdrawal status updated");

  res.json((await formatWithdrawals([w]))[0]);
});

// PATCH to change currency on pending withdrawal requests
router.patch("/withdrawals/:id/currency", requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const { currency } = req.body;
  const currencyRegex = /^[A-Z]{3}$/;
  if (!currency || !currencyRegex.test(currency)) {
    res.status(400).json({ error: "currency must be a valid 3-letter ISO 4217 code" });
    return;
  }

  const [w] = await db.select().from(withdrawalsTable).where(eq(withdrawalsTable.id, id));
  if (!w) { res.status(404).json({ error: "Withdrawal not found" }); return; }
  if (w.status !== "pending") {
    res.status(400).json({ error: "Can only change currency on pending withdrawals" });
    return;
  }

  const [updated] = await db.update(withdrawalsTable)
    .set({ currency })
    .where(eq(withdrawalsTable.id, id))
    .returning();

  logger.info({ 
    adminUserId: (req as any).userId, 
    withdrawalId: id, 
    oldCurrency: w.currency || "USD", 
    newCurrency: currency 
  }, "Withdrawal currency changed");

  res.json((await formatWithdrawals([updated]))[0]);
});

export default router;
