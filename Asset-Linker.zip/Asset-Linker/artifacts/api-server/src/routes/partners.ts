import { Router } from "express";
import { db, usersTable, partnersTable, profitDistributionsTable } from "@workspace/db";
import { eq, sql, and } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../lib/auth";

const router = Router();

function formatPartner(partner: any, user: any, monthlyEarnings?: number, pendingEarnings?: number) {
  return {
    id: partner.id,
    userId: partner.userId,
    sharesOwned: partner.sharesOwned,
    ownershipPercentage: Number(partner.ownershipPercentage),
    totalEarnings: Number(partner.totalEarnings),
    createdAt: partner.createdAt instanceof Date ? partner.createdAt.toISOString() : partner.createdAt,
    user: user ? {
      id: user.id,
      fullname: user.fullname,
      email: user.email,
      role: user.role,
      kycStatus: user.kycStatus,
      createdAt: user.createdAt instanceof Date ? user.createdAt.toISOString() : user.createdAt,
    } : null,
    monthlyEarnings: monthlyEarnings ?? null,
    pendingEarnings: pendingEarnings ?? null,
  };
}

router.get("/partners", requireAdmin, async (_req, res): Promise<void> => {
  const partners = await db.select().from(partnersTable).orderBy(partnersTable.createdAt);
  const result = await Promise.all(
    partners.map(async (p) => {
      const [user] = await db.select().from(usersTable).where(eq(usersTable.id, p.userId));
      const [pendingResult] = await db
        .select({ total: sql<number>`coalesce(sum(amount), 0)` })
        .from(profitDistributionsTable)
        .where(and(eq(profitDistributionsTable.partnerId, p.id), eq(profitDistributionsTable.status, "pending")));
      return formatPartner(p, user, undefined, Number(pendingResult?.total ?? 0));
    })
  );
  res.json(result);
});

router.get("/partners/me", requireAuth, async (req, res): Promise<void> => {
  const [partner] = await db.select().from(partnersTable).where(eq(partnersTable.userId, req.userId!));
  if (!partner) {
    res.status(404).json({ error: "Partner profile not found" });
    return;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!));

  const [pendingResult] = await db
    .select({ total: sql<number>`coalesce(sum(amount), 0)` })
    .from(profitDistributionsTable)
    .where(and(eq(profitDistributionsTable.partnerId, partner.id), eq(profitDistributionsTable.status, "pending")));

  const [monthlyResult] = await db
    .select({ total: sql<number>`coalesce(sum(amount), 0)` })
    .from(profitDistributionsTable)
    .where(eq(profitDistributionsTable.partnerId, partner.id));

  res.json(formatPartner(partner, user, Number(monthlyResult?.total ?? 0) / 12, Number(pendingResult?.total ?? 0)));
});

router.get("/partners/:id", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [partner] = await db.select().from(partnersTable).where(eq(partnersTable.id, id));
  if (!partner) { res.status(404).json({ error: "Not found" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, partner.userId));
  res.json(formatPartner(partner, user));
});

router.patch("/partners/:id", requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const { kycStatus, frozen } = req.body;
  const [partner] = await db.select().from(partnersTable).where(eq(partnersTable.id, id));
  if (!partner) { res.status(404).json({ error: "Not found" }); return; }

  if (kycStatus) {
    await db.update(usersTable).set({ kycStatus }).where(eq(usersTable.id, partner.userId));
  }
  if (frozen !== undefined && frozen !== null) {
    await db.update(usersTable).set({ frozen: String(frozen) }).where(eq(usersTable.id, partner.userId));
  }

  const [updated] = await db.select().from(partnersTable).where(eq(partnersTable.id, id));
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, updated.userId));
  res.json(formatPartner(updated, user));
});

export default router;
