import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import adminRouter from "./admin";
import partnersRouter from "./partners";
import shareTransactionsRouter from "./share-transactions";
import monthlyProfitsRouter from "./monthly-profits";
import profitDistributionsRouter from "./profit-distributions";
import withdrawalsRouter from "./withdrawals";
import kycDocumentsRouter from "./kyc-documents";
import invitationsRouter from "./invitations";
import paymentsRouter from "./payments";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(adminRouter);
router.use(partnersRouter);
router.use(shareTransactionsRouter);
router.use(monthlyProfitsRouter);
router.use(profitDistributionsRouter);
router.use(withdrawalsRouter);
router.use(kycDocumentsRouter);
router.use(invitationsRouter);
router.use(paymentsRouter);

export default router;
