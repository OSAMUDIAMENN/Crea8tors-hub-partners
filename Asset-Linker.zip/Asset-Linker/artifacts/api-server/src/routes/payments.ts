import { Router, Request, Response } from "express";
import { db, shareTransactionsTable, partnersTable, monthlyProfitsTable, usersTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import https from "https";
import crypto from "crypto";

const router = Router();

const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY || "sk_test_your_key_here";

// Helper to call Paystack API
function paystackRequest(path: string, method: string, data: any = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: "api.paystack.co",
      port: 443,
      path,
      method,
      headers: {
        Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
        "Content-Type": "application/json",
      },
    };

    const req = https.request(options, (res) => {
      let body = "";
      res.on("data", (chunk) => (body += chunk));
      res.on("end", () => {
        try {
          const response = JSON.parse(body);
          resolve(response);
        } catch (e) {
          reject(e);
        }
      });
    });

    req.on("error", reject);

    if (data) {
      req.write(JSON.stringify(data));
    }
    req.end();
  });
}

// Initialize Payment for Share Purchase
router.post("/payments/initialize", requireAuth, async (req, res): Promise<void> => {
  try {
    const userId = req.userId!;
    const { shares } = req.body;

    if (!shares || shares <= 0) {
      res.status(400).json({ error: "Valid number of shares is required" });
      return;
    }

    const MAX_SHARES_FOR_SALE = 300_000;

    // Get current total shares sold
    const [soldResult] = await db
      .select({ total: sql`coalesce(sum(shares), 0)` })
      .from(shareTransactionsTable)
      .where(eq(shareTransactionsTable.transactionType, "purchase"));

    const totalSold = Number(soldResult?.total ?? 0);

    if (totalSold + shares > MAX_SHARES_FOR_SALE) {
      res.status(400).json({ error: `Only ${MAX_SHARES_FOR_SALE - totalSold} shares remaining` });
      return;
    }

    // Get current share price
    const [latestProfit] = await db
      .select()
      .from(monthlyProfitsTable)
      .orderBy(desc(monthlyProfitsTable.createdAt))
      .limit(1);

    const currentPrice = latestProfit?.sharePrice 
      ? Number(latestProfit.sharePrice) 
      : 100;

    const amountInKobo = Math.round(shares * currentPrice * 100); // Paystack uses kobo

    // Get user email
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    // Initialize Paystack transaction
    const initializeData = await paystackRequest("/transaction/initialize", "POST", {
      email: user.email,
      amount: amountInKobo,
      currency: "NGN",
      metadata: {
        shares,
        userId,
        currentPrice,
        type: "share_purchase",
      },
    });

    if (!(initializeData as any).status) {
      res.status(400).json({ error: "Failed to initialize payment" });
      return;
    }

    res.json({
      authorization_url: (initializeData as any).data.authorization_url,
      access_code: (initializeData as any).data.access_code,
      reference: (initializeData as any).data.reference,
      shares,
      currentPrice,
      totalAmount: shares * currentPrice,
    });
  } catch (error) {
    console.error("Payment initialization error:", error);
    res.status(500).json({ error: "Failed to initialize payment" });
  }
});

// Verify Payment and Credit Shares
router.post("/payments/verify", requireAuth, async (req, res): Promise<void> => {
  try {
    const { reference } = req.body;
    const userId = req.userId!;

    if (!reference) {
      res.status(400).json({ error: "Payment reference is required" });
      return;
    }

    // Verify transaction with Paystack
    const verifyData: any = await paystackRequest(`/transaction/verify/${reference}`, "GET");

    if (!verifyData.status || verifyData.data.status !== "success") {
      res.status(400).json({ error: "Payment verification failed" });
      return;
    }

    const metadata = verifyData.data.metadata;
    const shares = Number(metadata.shares);
    const currentPrice = Number(metadata.currentPrice);

    if (!shares || !currentPrice) {
      res.status(400).json({ error: "Invalid payment metadata" });
      return;
    }

    // Simple duplicate check (can be improved with metadata column)
    // For now we rely on Paystack reference uniqueness

    // Credit the shares (reuse existing logic)
    const TOTAL_SHARES = 1_000_000;

    const [tx] = await db.insert(shareTransactionsTable).values({
      buyerId: userId,
      sellerId: null,
      shares,
      pricePerShare: String(currentPrice),
      transactionType: "purchase",
      // @ts-ignore - metadata column if exists
      metadata: { reference, paystackData: verifyData.data },
    }).returning();

    // Update partner's shares
    const [partner] = await db.select().from(partnersTable).where(eq(partnersTable.userId, userId));
    if (partner) {
      const newShares = partner.sharesOwned + shares;
      const newOwnership = (newShares / TOTAL_SHARES) * 100;

      await db.update(partnersTable).set({
        sharesOwned: newShares,
        ownershipPercentage: String(newOwnership.toFixed(6)),
      }).where(eq(partnersTable.id, partner.id));
    }

    // Send email receipt
    try {
      const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
      if (user) {
        await sendPaymentReceipt({
          userEmail: user.email,
          userName: user.fullname,
          shares,
          pricePerShare: currentPrice,
          totalAmount: shares * currentPrice,
          reference,
          date: new Date().toISOString(),
        });
      }
    } catch (emailError) {
      console.error("Failed to send receipt email:", emailError);
    }

    res.json({
      success: true,
      message: "Payment successful. Shares have been credited.",
      sharesCredited: shares,
      transaction: tx,
    });
  } catch (error) {
    console.error("Payment verification error:", error);
    res.status(500).json({ error: "Payment verification failed" });
  }
});

// Paystack Webhook Handler (More Reliable)
router.post("/payments/webhook", async (req: Request, res: Response): Promise<void> => {
  try {
    const hash = crypto
      .createHmac("sha512", PAYSTACK_SECRET_KEY)
      .update(JSON.stringify(req.body))
      .digest("hex");

    if (hash !== req.headers["x-paystack-signature"]) {
      console.log("Invalid webhook signature");
      res.sendStatus(400);
      return;
    }

    const event = req.body;

    // Only process successful charges
    if (event.event === "charge.success") {
      const data = event.data;
      const metadata = data.metadata || {};
      const shares = Number(metadata.shares);
      const currentPrice = Number(metadata.currentPrice);
      const userId = Number(metadata.userId);
      const reference = data.reference;

      if (!shares || !currentPrice || !userId) {
        console.log("Invalid metadata in webhook");
        res.sendStatus(200); // Acknowledge anyway
        return;
      }

      // Check if already processed
      const [existing] = await db
        .select()
        .from(shareTransactionsTable)
        .where(eq(shareTransactionsTable.buyerId, userId));

      // Simple check - in production use a dedicated reference column
      const alreadyProcessed = false; // You can improve this with metadata check

      if (!alreadyProcessed) {
        const TOTAL_SHARES = 1_000_000;

        // Credit shares
        await db.insert(shareTransactionsTable).values({
          buyerId: userId,
          sellerId: null,
          shares,
          pricePerShare: String(currentPrice),
          transactionType: "purchase",
        });

        // Update partner shares
        const [partner] = await db.select().from(partnersTable).where(eq(partnersTable.userId, userId));
        if (partner) {
          const newShares = partner.sharesOwned + shares;
          const newOwnership = (newShares / TOTAL_SHARES) * 100;

          await db.update(partnersTable).set({
            sharesOwned: newShares,
            ownershipPercentage: String(newOwnership.toFixed(6)),
          }).where(eq(partnersTable.id, partner.id));
        }

        console.log(`Webhook: Credited ${shares} shares to user ${userId}`);

        // Send email receipt from webhook
        try {
          const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
          if (user) {
            await sendPaymentReceipt({
              userEmail: user.email,
              userName: user.fullname,
              shares,
              pricePerShare: currentPrice,
              totalAmount: shares * currentPrice,
              reference: data.reference,
              date: new Date().toISOString(),
            });
          }
        } catch (emailError) {
          console.error("Failed to send receipt email from webhook:", emailError);
        }
      }
    }

    res.sendStatus(200); // Always acknowledge quickly
  } catch (error) {
    console.error("Webhook error:", error);
    res.sendStatus(200); // Still acknowledge to prevent retries
  }
});

export default router;
