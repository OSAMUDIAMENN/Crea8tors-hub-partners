import { Router } from "express";
import { db, profitDistributionsTable, partnersTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../lib/auth";

const router = Router();

router.get("/profit-distributions", requireAuth, async (req, res): Promise<void> => {
  let distributions;

  if (req.userRole === "admin") {
    distributions = await db.select().from(profitDistributionsTable).orderBy(profitDistributionsTable.createdAt);
  } else {
    const [partner] = await db.select().from(partnersTable).where(eq(partnersTable.userId, req.userId!));
    if (!partner) { res.json([]); return; }
    distributions = await db.select().from(profitDistributionsTable)
      .where(eq(profitDistributionsTable.partnerId, partner.id))
      .orderBy(profitDistributionsTable.createdAt);
  }

  const result = await Promise.all(distributions.map(async (d) => {
    const [partner] = await db.select().from(partnersTable).where(eq(partnersTable.id, d.partnerId));
    let partnerName: string | null = null;
    if (partner) {
      const [user] = await db.select().from(usersTable).where(eq(usersTable.id, partner.userId));
      partnerName = user?.fullname ?? null;
    }
    return {
      id: d.id,
      partnerId: d.partnerId,
      profitMonth: d.profitMonth,
      amount: Number(d.amount),
      status: d.status,
      createdAt: d.createdAt instanceof Date ? d.createdAt.toISOString() : d.createdAt,
      partnerName,
    };
  }));

  res.json(result);
});

export default router;
