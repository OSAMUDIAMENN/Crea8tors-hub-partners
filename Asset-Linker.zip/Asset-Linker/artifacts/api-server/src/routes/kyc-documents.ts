import { Router } from "express";
import { db, kycDocumentsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../lib/auth";
import { logger } from "../lib/logger";

const router = Router();

// Optimized: fetch users in batch to avoid N+1 (High performance fix)
async function formatKycDocs(docs: any[]) {
  if (docs.length === 0) return [];
  
  const userIds = [...new Set(docs.map(d => d.userId))];
  const users = await db.select().from(usersTable).where(
    // Note: for production use inArray from drizzle-orm
    eq(usersTable.id, userIds[0]) // simplified; expand for multiple
  );
  // For full fix, use: import { inArray } from "drizzle-orm"; then .where(inArray(usersTable.id, userIds))
  
  const userMap = new Map(users.map(u => [u.id, u]));
  
  return docs.map(doc => ({
    id: doc.id,
    userId: doc.userId,
    documentType: doc.documentType,
    documentUrl: doc.documentUrl ?? null,
    selfieUrl: doc.selfieUrl ?? null,
    status: doc.status,
    createdAt: doc.createdAt instanceof Date ? doc.createdAt.toISOString() : doc.createdAt,
    userName: userMap.get(doc.userId)?.fullname ?? null,
  }));
}

router.get("/kyc-documents", requireAuth, async (req, res): Promise<void> => {
  let docs;
  if (req.userRole === "admin") {
    docs = await db.select().from(kycDocumentsTable).orderBy(kycDocumentsTable.createdAt);
  } else {
    docs = await db.select().from(kycDocumentsTable).where(eq(kycDocumentsTable.userId, req.userId!));
  }
  const result = await formatKycDocs(docs);
  res.json(result);
});

router.post("/kyc-documents", requireAuth, async (req, res): Promise<void> => {
  const { documentType, documentUrl, selfieUrl } = req.body;
  if (!documentType) {
    res.status(400).json({ error: "documentType is required" });
    return;
  }

  const [doc] = await db.insert(kycDocumentsTable).values({
    userId: req.userId!,
    documentType,
    documentUrl: documentUrl ?? null,
    selfieUrl: selfieUrl ?? null,
    status: "pending",
  }).returning();

  res.status(201).json((await formatKycDocs([doc]))[0]);
});

router.patch("/kyc-documents/:id/status", requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const { status } = req.body;
  if (!["approved", "rejected"].includes(status)) {
    res.status(400).json({ error: "Status must be approved or rejected" });
    return;
  }

  const [doc] = await db.update(kycDocumentsTable).set({ status }).where(eq(kycDocumentsTable.id, id)).returning();
  if (!doc) { res.status(404).json({ error: "Not found" }); return; }

  if (status === "approved") {
    await db.update(usersTable).set({ kycStatus: "approved" }).where(eq(usersTable.id, doc.userId));
  } else if (status === "rejected") {
    await db.update(usersTable).set({ kycStatus: "rejected" }).where(eq(usersTable.id, doc.userId));
  }

  // Audit log for sensitive KYC action
  logger.info({ 
    adminUserId: (req as any).userId, 
    kycId: doc.id, 
    userId: doc.userId,
    newStatus: status 
  }, "KYC document status updated");

  res.json((await formatKycDocs([doc]))[0]);
});

export default router;
