import { Router } from "express";
import { db, monthlyProfitsTable, partnersTable, profitDistributionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../lib/auth";
import { logger } from "../lib/logger";

const router = Router();

const TOTAL_SHARES = 1_000_000;

function formatProfit(mp: any) {
  return {
    id: mp.id,
    month: mp.month,
    totalProfit: Number(mp.totalProfit),
    distributableProfit: Number(mp.distributableProfit),
    distributed: mp.distributed,
    currency: mp.currency || "NGN",
    sharePrice: mp.sharePrice ? Number(mp.sharePrice) : 100,
    priceChangePercent: mp.priceChangePercent ? Number(mp.priceChangePercent) : 0,
    createdAt: mp.createdAt instanceof Date ? mp.createdAt.toISOString() : mp.createdAt,
  };
}

router.get("/monthly-profits", requireAuth, async (_req, res): Promise<void> => {
  const profits = await db.select().from(monthlyProfitsTable).orderBy(monthlyProfitsTable.createdAt);
  res.json(profits.map(formatProfit));
});

router.post("/monthly-profits", requireAdmin, async (req, res): Promise<void> => {
  const { month, totalProfit, distributableProfit, currency = "NGN" } = req.body;

  if (!month || totalProfit == null || distributableProfit == null) {
    res.status(400).json({ error: "month, totalProfit, and distributableProfit are required" });
    return;
  }

  // Validate currency (ISO 4217 3-letter code)
  const currencyRegex = /^[A-Z]{3}$/;
  if (!currencyRegex.test(currency)) {
    res.status(400).json({ error: "currency must be a valid 3-letter ISO 4217 code (e.g. USD, EUR)" });
    return;
  }

  // Auto-increase share price by 1% monthly according to net profit
  const [previousProfit] = await db
    .select()
    .from(monthlyProfitsTable)
    .orderBy(desc(monthlyProfitsTable.createdAt))
    .limit(1);

  let newSharePrice = 100; // starting price (NGN)
  let priceChangePercent = 0;

  if (previousProfit && previousProfit.sharePrice) {
    const previousPrice = Number(previousProfit.sharePrice);
    const distributable = Number(previousProfit.distributableProfit);

    // Dynamic pricing based on net profit performance
    if (distributable > 0) {
      // Higher profit = higher increase (0.5% to 5%)
      // Example: ₦50k profit ≈ +1%, ₦250k+ profit ≈ +5%
      priceChangePercent = Math.min((distributable / 50000) * 0.01, 0.05);
      priceChangePercent = Math.max(priceChangePercent, 0.005); // minimum +0.5%
    } else {
      // Low profit → small reduction
      priceChangePercent = -0.003; // -0.3%
    }

    newSharePrice = previousPrice * (1 + priceChangePercent);
  }

  const [mp] = await db.insert(monthlyProfitsTable).values({
    month,
    totalProfit: String(totalProfit),
    distributableProfit: String(distributableProfit),
    distributed: false,
    currency,
    sharePrice: String(newSharePrice.toFixed(2)),
    priceChangePercent: String((priceChangePercent * 100).toFixed(2)),
  }).returning();

  // Audit log for monthly profit record creation (including currency)
  logger.info({ 
    adminUserId: (req as any).userId, 
    profitId: mp.id, 
    month: mp.month,
    totalProfit: mp.totalProfit,
    distributableProfit: mp.distributableProfit,
    currency: mp.currency 
  }, "Monthly profit record created");

  res.status(201).json(formatProfit(mp));
});

router.post("/monthly-profits/:id/distribute", requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  // Use a DB transaction for atomicity (Critical fix)
  await db.transaction(async (tx) => {
    const [mp] = await tx.select().from(monthlyProfitsTable).where(eq(monthlyProfitsTable.id, id));
    if (!mp) {
      res.status(404).json({ error: "Monthly profit not found" });
      return;
    }
    if (mp.distributed) {
      res.status(400).json({ error: "Already distributed" });
      return;
    }

    const distributableProfit = Number(mp.distributableProfit); // TODO: replace with precise decimal handling
    const partners = await tx.select().from(partnersTable);

    let distributionsCreated = 0;
    let totalAmount = 0;

    for (const partner of partners) {
      if (partner.sharesOwned === 0) continue;
      const amount = (partner.sharesOwned / TOTAL_SHARES) * distributableProfit;
      if (amount <= 0) continue;

      await tx.insert(profitDistributionsTable).values({
        partnerId: partner.id,
        profitMonth: mp.month,
        amount: String(amount.toFixed(2)),
        status: "pending",
        currency: mp.currency || "USD", // Inherit currency from the profit record
      });

      const newTotalEarnings = Number(partner.totalEarnings) + amount;
      await tx.update(partnersTable).set({
        totalEarnings: String(newTotalEarnings.toFixed(2)),
      }).where(eq(partnersTable.id, partner.id));

      distributionsCreated++;
      totalAmount += amount;
    }

    await tx.update(monthlyProfitsTable).set({ distributed: true }).where(eq(monthlyProfitsTable.id, id));

    // Audit log for sensitive financial action (Fix 10)
    logger.info({ 
      adminUserId: (req as any).userId, 
      month: mp.month, 
      distributionsCreated, 
      totalAmount 
    }, "Profit distribution executed");

    res.json({ distributionsCreated, totalAmount: parseFloat(totalAmount.toFixed(2)) });
  });
});

// PATCH endpoint to change currency on existing undistributed profit records
router.patch("/monthly-profits/:id/currency", requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { 
    res.status(400).json({ error: "Invalid id" }); 
    return; 
  }

  const { currency } = req.body;
  const currencyRegex = /^[A-Z]{3}$/;
  if (!currency || !currencyRegex.test(currency)) {
    res.status(400).json({ error: "currency must be a valid 3-letter ISO 4217 code (e.g. USD, EUR)" });
    return;
  }

  const [mp] = await db.select().from(monthlyProfitsTable).where(eq(monthlyProfitsTable.id, id));
  if (!mp) { 
    res.status(404).json({ error: "Profit record not found" }); 
    return; 
  }
  if (mp.distributed) {
    res.status(400).json({ error: "Cannot change currency on already distributed records" });
    return;
  }

  const [updated] = await db.update(monthlyProfitsTable)
    .set({ currency })
    .where(eq(monthlyProfitsTable.id, id))
    .returning();

  // Audit logging for currency change
  logger.info({ 
    adminUserId: (req as any).userId, 
    profitId: id, 
    oldCurrency: mp.currency || "USD", 
    newCurrency: currency 
  }, "Monthly profit currency changed");

  res.json(formatProfit(updated));
});

export default router;
