import { Router } from "express";
import { db, shareTransactionsTable, partnersTable, usersTable, monthlyProfitsTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../lib/auth";

const router = Router();

function formatTx(tx: any, buyerName?: string | null, sellerName?: string | null) {
  return {
    id: tx.id,
    buyerId: tx.buyerId,
    sellerId: tx.sellerId,
    shares: tx.shares,
    pricePerShare: Number(tx.pricePerShare),
    transactionType: tx.transactionType,
    createdAt: tx.createdAt instanceof Date ? tx.createdAt.toISOString() : tx.createdAt,
    buyerName: buyerName ?? null,
    sellerName: sellerName ?? null,
  };
}

router.get("/share-transactions", requireAuth, async (req, res): Promise<void> => {
  const txs = await db.select().from(shareTransactionsTable).orderBy(shareTransactionsTable.createdAt);

  const result = await Promise.all(txs.map(async (tx) => {
    let buyerName: string | null = null;
    let sellerName: string | null = null;
    if (tx.buyerId) {
      const [u] = await db.select().from(usersTable).where(eq(usersTable.id, tx.buyerId));
      buyerName = u?.fullname ?? null;
    }
    if (tx.sellerId) {
      const [u] = await db.select().from(usersTable).where(eq(usersTable.id, tx.sellerId));
      sellerName = u?.fullname ?? null;
    }
    return formatTx(tx, buyerName, sellerName);
  }));

  res.json(result);
});

router.post("/share-transactions", requireAdmin, async (req, res): Promise<void> => {
  const { buyerId, sellerId, shares, pricePerShare, transactionType } = req.body;

  if (!shares || !pricePerShare || !transactionType) {
    res.status(400).json({ error: "shares, pricePerShare, and transactionType are required" });
    return;
  }

  const TOTAL_SHARES = 1_000_000;

  const [tx] = await db.insert(shareTransactionsTable).values({
    buyerId: buyerId ?? null,
    sellerId: sellerId ?? null,
    shares,
    pricePerShare: String(pricePerShare),
    transactionType,
  }).returning();

  if (buyerId && (transactionType === "purchase" || transactionType === "transfer")) {
    const [buyerPartner] = await db.select().from(partnersTable).where(eq(partnersTable.userId, buyerId));
    if (buyerPartner) {
      const newShares = buyerPartner.sharesOwned + shares;
      const newOwnership = (newShares / TOTAL_SHARES) * 100;
      await db.update(partnersTable).set({
        sharesOwned: newShares,
        ownershipPercentage: String(newOwnership.toFixed(6)),
      }).where(eq(partnersTable.id, buyerPartner.id));
    }
  }

  if (sellerId && (transactionType === "transfer" || transactionType === "buyback")) {
    const [sellerPartner] = await db.select().from(partnersTable).where(eq(partnersTable.userId, sellerId));
    if (sellerPartner) {
      const newShares = Math.max(0, sellerPartner.sharesOwned - shares);
      const newOwnership = (newShares / TOTAL_SHARES) * 100;
      await db.update(partnersTable).set({
        sharesOwned: newShares,
        ownershipPercentage: String(newOwnership.toFixed(6)),
      }).where(eq(partnersTable.id, sellerPartner.id));
    }
  }

  let buyerName: string | null = null;
  let sellerName: string | null = null;
  if (tx.buyerId) {
    const [u] = await db.select().from(usersTable).where(eq(usersTable.id, tx.buyerId));
    buyerName = u?.fullname ?? null;
  }
  if (tx.sellerId) {
    const [u] = await db.select().from(usersTable).where(eq(usersTable.id, tx.sellerId));
    sellerName = u?.fullname ?? null;
  }

  res.status(201).json(formatTx(tx, buyerName, sellerName));
});

// Partner can buy shares (frontend purchase)
router.post("/share-transactions/buy", requireAuth, async (req, res): Promise<void> => {
  const userId = req.userId!;
  const { shares } = req.body;

  if (!shares || shares <= 0) {
    res.status(400).json({ error: "Valid number of shares is required" });
    return;
  }

  const TOTAL_SHARES = 1_000_000;
  const MAX_SHARES_FOR_SALE = 300_000;

  // Get current total shares sold
  const [soldResult] = await db
    .select({ total: sql`coalesce(sum(shares), 0)` })
    .from(shareTransactionsTable)
    .where(eq(shareTransactionsTable.transactionType, "purchase"));

  const totalSold = Number(soldResult?.total ?? 0);

  if (totalSold + shares > MAX_SHARES_FOR_SALE) {
    res.status(400).json({ 
      error: `Purchase limit reached. Only ${MAX_SHARES_FOR_SALE - totalSold} shares remaining.` 
    });
    return;
  }

  // Get current share price from latest monthly profit or default
  const [latestProfit] = await db
    .select()
    .from(monthlyProfitsTable)
    .orderBy(desc(monthlyProfitsTable.createdAt))
    .limit(1);

  let currentPrice = 100; // default starting price (NGN)
  if (latestProfit && latestProfit.sharePrice) {
    currentPrice = Number(latestProfit.sharePrice);
  }

  const totalCost = shares * currentPrice;

  // Create purchase transaction
  const [tx] = await db.insert(shareTransactionsTable).values({
    buyerId: userId,
    sellerId: null,
    shares,
    pricePerShare: String(currentPrice),
    transactionType: "purchase",
  }).returning();

  // Update partner's sharesOwned
  const [partner] = await db.select().from(partnersTable).where(eq(partnersTable.userId, userId));
  if (partner) {
    const newShares = partner.sharesOwned + shares;
    const newOwnership = (newShares / TOTAL_SHARES) * 100;
    await db.update(partnersTable).set({
      sharesOwned: newShares,
      ownershipPercentage: String(newOwnership.toFixed(6)),
    }).where(eq(partnersTable.id, partner.id));
  }

  res.status(201).json({
    success: true,
    transaction: formatTx(tx),
    sharesPurchased: shares,
    pricePerShare: currentPrice,
    totalCost: totalCost.toFixed(2),
    remainingSharesForSale: MAX_SHARES_FOR_SALE - (totalSold + shares),
  });
});

// Public market stats for partners (current price + remaining shares)
router.get("/market/stats", requireAuth, async (req, res): Promise<void> => {
  const MAX_SHARES_FOR_SALE = 300_000;

  // Total shares sold
  const [soldResult] = await db
    .select({ total: sql`coalesce(sum(shares), 0)` })
    .from(shareTransactionsTable)
    .where(eq(shareTransactionsTable.transactionType, "purchase"));

  const totalSold = Number(soldResult?.total ?? 0);
  const remaining = MAX_SHARES_FOR_SALE - totalSold;

  // Current share price
  const [latestProfit] = await db
    .select()
    .from(monthlyProfitsTable)
    .orderBy(desc(monthlyProfitsTable.createdAt))
    .limit(1);

  const currentPrice = latestProfit?.sharePrice 
    ? Number(latestProfit.sharePrice) 
    : 100;

  res.json({
    currentSharePrice: currentPrice,
    sharesRemaining: remaining,
    totalSharesForSale: MAX_SHARES_FOR_SALE,
    totalSharesSold: totalSold
  });
});

export default router;
