import { logger } from "./logger";

interface PaymentReceiptData {
  userEmail: string;
  userName: string;
  shares: number;
  pricePerShare: number;
  totalAmount: number;
  reference: string;
  date: string;
}

/**
 * Send payment receipt email
 * TODO: Replace with real email service (Nodemailer, SendGrid, Resend, etc.)
 */
export async function sendPaymentReceipt(data: PaymentReceiptData) {
  const { userEmail, userName, shares, pricePerShare, totalAmount, reference, date } = data;

  const emailContent = `
    <h2>Payment Receipt - CreatorHub</h2>
    <p>Dear ${userName},</p>
    
    <p>Thank you for your investment in CreatorHub!</p>
    
    <h3>Transaction Details:</h3>
    <ul>
      <li><strong>Reference:</strong> ${reference}</li>
      <li><strong>Date:</strong> ${date}</li>
      <li><strong>Shares Purchased:</strong> ${shares}</li>
      <li><strong>Price per Share:</strong> ₦${pricePerShare}</li>
      <li><strong>Total Amount:</strong> ₦${totalAmount}</li>
    </ul>

    <p>Your shares have been successfully credited to your account.</p>
    
    <p>Best regards,<br/>
    The CreatorHub Team</p>
  `;

  // For now, just log it. Replace with actual email sending.
  logger.info({
    to: userEmail,
    subject: "CreatorHub - Payment Receipt",
    shares,
    totalAmount,
    reference,
  }, "Payment receipt generated (email sending not configured yet)");

  // Example with Nodemailer (uncomment and configure when ready):
  /*
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: 587,
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  await transporter.sendMail({
    from: '"CreatorHub" <no-reply@creatorhub.io>',
    to: userEmail,
    subject: "CreatorHub - Payment Receipt",
    html: emailContent,
  });
  */

  return true;
}
