import { useEffect, useState, useCallback } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Download, RefreshCw, AlertCircle } from "lucide-react";

interface PaymentTransaction {
  id: number;
  createdAt: string;
  shares: number;
  pricePerShare: number;
  transactionType: string;
  paystackReference: string | null;
  currentPrice: number;
  currentValue: number;
  purchaseValue: number;
  gainLoss: number;
  gainLossPercent: number;
}

export default function PaymentsHistory() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [transactions, setTransactions] = useState<PaymentTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [downloadingRef, setDownloadingRef] = useState<string | null>(null);

  const fetchPayments = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem("authToken");
      const res = await fetch("/api/payments/my-payments", {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || "Failed to load payment history");
      }
      const data = await res.json();
      setTransactions(data);
    } catch (err: any) {
      setError(err.message || "Failed to load payment history");
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    if (user) fetchPayments();
  }, [user, fetchPayments]);

  const handleDownloadReceipt = async (reference: string | null) => {
    if (!reference) {
      toast({ title: "No receipt available", description: "This transaction has no Paystack reference.", variant: "destructive" });
      return;
    }
    setDownloadingRef(reference);
    try {
      const token = localStorage.getItem("authToken");
      const res = await fetch(`/api/payments/receipt/${reference}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) throw new Error("Receipt not found");
      const html = await res.text();
      const blob = new Blob([html], { type: "text/html" });
      const url = URL.createObjectURL(blob);
      const win = window.open(url, "_blank");
      if (!win) toast({ title: "Popup blocked", description: "Please allow popups and try again." });
    } catch (err: any) {
      toast({ title: "Receipt failed", description: err.message, variant: "destructive" });
    } finally {
      setDownloadingRef(null);
    }
  };

  if (loading) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-64" />
          <div className="h-4 bg-muted rounded w-96" />
          <div className="h-64 bg-muted rounded" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="flex flex-col items-center justify-center py-16 gap-4 text-center">
          <AlertCircle className="w-12 h-12 text-destructive" />
          <h2 className="text-xl font-semibold">Failed to load payment history</h2>
          <p className="text-muted-foreground">{error}</p>
          <Button onClick={fetchPayments} variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" /> Try Again
          </Button>
        </div>
      </div>
    );
  }

  const currentPrice = transactions[0]?.currentPrice ?? 100;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Payment History</h1>
          <p className="text-muted-foreground mt-1">View all your share purchases and investment performance</p>
        </div>
        <Button onClick={fetchPayments} variant="outline" size="sm">
          <RefreshCw className="w-4 h-4 mr-2" /> Refresh
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Share Purchases</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Shares</TableHead>
                <TableHead>Purchase Price</TableHead>
                <TableHead>Amount Paid</TableHead>
                <TableHead>Current Value</TableHead>
                <TableHead>Gain / Loss</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Receipt</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.length > 0 ? (
                transactions.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell>{new Date(tx.createdAt).toLocaleDateString("en-NG", { year: "numeric", month: "short", day: "numeric" })}</TableCell>
                    <TableCell className="font-medium">{tx.shares.toLocaleString()}</TableCell>
                    <TableCell>₦{tx.pricePerShare?.toFixed(2)}</TableCell>
                    <TableCell>₦{tx.purchaseValue?.toLocaleString()}</TableCell>
                    <TableCell>₦{tx.currentValue?.toLocaleString()}</TableCell>
                    <TableCell>
                      <div className={tx.gainLoss >= 0 ? "text-green-600" : "text-red-600"}>
                        {tx.gainLoss >= 0 ? "+" : ""}₦{tx.gainLoss?.toFixed(2)}
                        <span className="text-xs ml-1">({tx.gainLossPercent >= 0 ? "+" : ""}{tx.gainLossPercent?.toFixed(1)}%)</span>
                      </div>
                    </TableCell>
                    <TableCell><Badge variant="default">Completed</Badge></TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDownloadReceipt(tx.paystackReference)}
                        disabled={downloadingRef === tx.paystackReference || !tx.paystackReference}
                        title={!tx.paystackReference ? "No receipt available" : "View receipt"}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                    No share purchases yet. Start investing from your dashboard!
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="text-sm text-muted-foreground">
        Current values use the latest share price of ₦{currentPrice.toFixed(2)}. 
        Gain/loss is relative to your original purchase price.
      </div>
    </div>
  );
}
