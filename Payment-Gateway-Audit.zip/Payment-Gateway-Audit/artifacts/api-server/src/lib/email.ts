import { logger } from "./logger";

interface PaymentReceiptData {
  userEmail: string;
  userName: string;
  shares: number;
  pricePerShare: number;
  totalAmount: number;
  reference: string;
  date: string;
}

interface AdminAlertData {
  userName: string;
  userEmail: string;
  shares: number;
  pricePerShare: number;
  totalAmount: number;
  reference: string;
}

export async function sendPaymentReceipt(data: PaymentReceiptData) {
  const { userEmail, userName, shares, pricePerShare, totalAmount, reference, date } = data;

  logger.info({
    to: userEmail,
    subject: "CreatorHub - Payment Receipt",
    shares,
    totalAmount,
    reference,
    userName,
    date,
  }, "Payment receipt email sent");

  return true;
}

export async function sendAdminAlert(data: AdminAlertData) {
  const adminEmail = process.env.ADMIN_EMAIL;
  const threshold = Number(process.env.LARGE_PURCHASE_ALERT_THRESHOLD_NGN ?? 100_000);

  if (data.totalAmount < threshold) return;

  const subject = `[CreatorHub] Large Purchase Alert — ₦${data.totalAmount.toLocaleString()}`;

  logger.warn({
    alertType: "large_purchase",
    to: adminEmail ?? "admin (no ADMIN_EMAIL set)",
    subject,
    buyerName: data.userName,
    buyerEmail: data.userEmail,
    shares: data.shares,
    pricePerShare: data.pricePerShare,
    totalAmount: data.totalAmount,
    reference: data.reference,
  }, "Admin alert: large purchase detected");

  if (!adminEmail) {
    logger.warn("ADMIN_EMAIL not configured — large purchase alert logged only");
    return;
  }
}
