import { Router } from "express";
import {
  db,
  usersTable,
  partnersTable,
  withdrawalsTable,
  kycDocumentsTable,
  monthlyProfitsTable,
  profitDistributionsTable,
  shareTransactionsTable,
} from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { requireAdmin } from "../lib/auth";

const router = Router();

router.get("/admin/overview", requireAdmin, async (req, res): Promise<void> => {
  const [partnerCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(partnersTable);
  const [sharesSoldResult] = await db
    .select({ total: sql<number>`coalesce(sum(shares_owned), 0)` })
    .from(partnersTable);
  const [capitalResult] = await db
    .select({ total: sql<number>`coalesce(sum(shares * price_per_share), 0)` })
    .from(shareTransactionsTable)
    .where(eq(shareTransactionsTable.transactionType, "purchase"));
  const [pendingWithdrawals] = await db
    .select({ count: sql<number>`count(*)` })
    .from(withdrawalsTable)
    .where(eq(withdrawalsTable.status, "pending"));
  const [pendingKyc] = await db
    .select({ count: sql<number>`count(*)` })
    .from(kycDocumentsTable)
    .where(eq(kycDocumentsTable.status, "pending"));
  const [lastProfit] = await db
    .select({ profit: monthlyProfitsTable.distributableProfit, sharePrice: monthlyProfitsTable.sharePrice })
    .from(monthlyProfitsTable)
    .orderBy(sql`created_at desc`)
    .limit(1);
  const [totalDistributed] = await db
    .select({ total: sql<number>`coalesce(sum(amount), 0)` })
    .from(profitDistributionsTable);

  const sharesSold = Number(sharesSoldResult.total ?? 0);
  const currentSharePrice = lastProfit?.sharePrice ? Number(lastProfit.sharePrice) : 100;
  const totalMarketValue = sharesSold * currentSharePrice;

  res.json({
    totalInvestors: Number(partnerCount.count),
    sharesSold,
    sharesRemaining: 300000 - sharesSold,
    currentSharePrice,
    totalMarketValue: Math.round(totalMarketValue),
    totalCapitalRaised: Number(capitalResult.total ?? 0),
    pendingWithdrawals: Number(pendingWithdrawals.count),
    pendingKyc: Number(pendingKyc.count),
    lastMonthProfit: Number(lastProfit?.profit ?? 0),
    totalDistributed: Number(totalDistributed.total ?? 0),
  });
});

export default router;
