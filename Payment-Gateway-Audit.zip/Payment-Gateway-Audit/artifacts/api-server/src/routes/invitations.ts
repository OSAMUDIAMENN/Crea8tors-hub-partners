import { Router } from "express";
import { db, invitationsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAdmin } from "../lib/auth";
import crypto from "crypto";
import { logger } from "../lib/logger";

const router = Router();

function formatInvitation(inv: any) {
  return {
    id: inv.id,
    email: inv.email,
    token: inv.token,
    used: inv.used,
    expiresAt: inv.expiresAt instanceof Date ? inv.expiresAt.toISOString() : inv.expiresAt,
    createdAt: inv.createdAt instanceof Date ? inv.createdAt.toISOString() : inv.createdAt,
  };
}

router.get("/invitations", requireAdmin, async (_req, res): Promise<void> => {
  const invitations = await db
    .select()
    .from(invitationsTable)
    .orderBy(invitationsTable.createdAt);
  res.json(invitations.map(formatInvitation));
});

router.post("/invitations", requireAdmin, async (req, res): Promise<void> => {
  const { email } = req.body;
  if (!email) {
    res.status(400).json({ error: "email is required" });
    return;
  }

  const token = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

  const [inv] = await db
    .insert(invitationsTable)
    .values({ email, token, used: false, expiresAt })
    .returning();

  logger.info(
    {
      adminUserId: (req as any).userId,
      invitationId: inv.id,
      email: inv.email,
      expiresAt: inv.expiresAt,
    },
    "Invitation created"
  );

  res.status(201).json(formatInvitation(inv));
});

router.delete("/invitations/:id", requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const [inv] = await db
    .delete(invitationsTable)
    .where(eq(invitationsTable.id, id))
    .returning();
  if (!inv) {
    res.status(404).json({ error: "Not found" });
    return;
  }

  logger.info(
    { adminUserId: (req as any).userId, invitationId: inv.id, email: inv.email },
    "Invitation revoked/deleted"
  );

  res.sendStatus(204);
});

export default router;
