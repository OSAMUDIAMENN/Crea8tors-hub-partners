import { Router } from "express";
import { db, profitDistributionsTable, partnersTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import { logger } from "../lib/logger";

const router = Router();

router.get("/profit-distributions", requireAuth, async (req, res): Promise<void> => {
  let distributions;

  if (req.userRole === "admin") {
    distributions = await db
      .select()
      .from(profitDistributionsTable)
      .orderBy(profitDistributionsTable.createdAt);
  } else {
    const [partner] = await db
      .select()
      .from(partnersTable)
      .where(eq(partnersTable.userId, req.userId!));
    if (!partner) {
      res.json([]);
      return;
    }

    // Enforce 6-month profit lock: check if the partner's lock has expired
    const now = new Date();
    if (partner.profitLockEndsAt && partner.profitLockEndsAt > now) {
      const lockedUntil = partner.profitLockEndsAt.toISOString();
      logger.info({ partnerId: partner.id, lockedUntil }, "Profit distributions locked");
      res.json({
        locked: true,
        lockedUntil,
        message: "Your profit distributions are locked for 6 months from your first share purchase.",
        distributions: [],
      });
      return;
    }

    distributions = await db
      .select()
      .from(profitDistributionsTable)
      .where(eq(profitDistributionsTable.partnerId, partner.id))
      .orderBy(profitDistributionsTable.createdAt);
  }

  const result = await Promise.all(
    distributions.map(async (d) => {
      const [partner] = await db
        .select()
        .from(partnersTable)
        .where(eq(partnersTable.id, d.partnerId));
      let partnerName: string | null = null;
      if (partner) {
        const [user] = await db
          .select()
          .from(usersTable)
          .where(eq(usersTable.id, partner.userId));
        partnerName = user?.fullname ?? null;
      }
      return {
        id: d.id,
        partnerId: d.partnerId,
        profitMonth: d.profitMonth,
        amount: Number(d.amount),
        status: d.status,
        currency: d.currency,
        createdAt: d.createdAt instanceof Date ? d.createdAt.toISOString() : d.createdAt,
        partnerName,
      };
    })
  );

  res.json(result);
});

export default router;
