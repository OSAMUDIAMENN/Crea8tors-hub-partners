import { Router, Request, Response, NextFunction } from "express";
import {
  db,
  shareTransactionsTable,
  partnersTable,
  monthlyProfitsTable,
  usersTable,
  processedWebhooksTable,
} from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import { logger } from "../lib/logger";
import { sendPaymentReceipt, sendAdminAlert } from "../lib/email";
import https from "https";
import crypto from "crypto";

const router = Router();

function getPaystackKey(): string {
  const key = process.env.PAYSTACK_SECRET_KEY;
  if (!key) throw new Error("PAYSTACK_SECRET_KEY environment variable is not set. Please add it to your secrets.");
  return key;
}

const TOTAL_SHARES = 1_000_000;
const MAX_SHARES_FOR_SALE = 300_000;
const SIX_MONTHS_MS = 6 * 30 * 24 * 60 * 60 * 1000;

const paymentRateLimitStore = new Map<string, { count: number; resetTime: number }>();

function paymentRateLimit(req: Request, res: Response, next: NextFunction) {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const userId = (req as any).userId ?? "anon";
  const key = `payment:${ip}:${userId}`;
  const now = Date.now();
  const windowMs = 60 * 60 * 1000;
  const maxRequests = 10;

  const record = paymentRateLimitStore.get(key);
  if (!record || now > record.resetTime) {
    paymentRateLimitStore.set(key, { count: 1, resetTime: now + windowMs });
    return next();
  }
  if (record.count >= maxRequests) {
    logger.warn({ ip, userId }, "Payment rate limit hit");
    res.status(429).json({ error: "Too many payment requests. Please wait before trying again." });
    return;
  }
  record.count++;
  next();
}

function paystackRequest(path: string, method: string, data: any = null) {
  const key = getPaystackKey();
  return new Promise((resolve, reject) => {
    const options = {
      hostname: "api.paystack.co",
      port: 443,
      path,
      method,
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
    };

    const req = https.request(options, (res) => {
      let body = "";
      res.on("data", (chunk) => (body += chunk));
      res.on("end", () => {
        try {
          resolve(JSON.parse(body));
        } catch (e) {
          reject(e);
        }
      });
    });

    req.on("error", reject);
    if (data) req.write(JSON.stringify(data));
    req.end();
  });
}

// GET /payments/my-payments — authenticated user's own purchase history
router.get("/payments/my-payments", requireAuth, async (req, res): Promise<void> => {
  const userId = req.userId!;
  try {
    const transactions = await db
      .select()
      .from(shareTransactionsTable)
      .where(eq(shareTransactionsTable.buyerId, userId))
      .orderBy(desc(shareTransactionsTable.createdAt));

    const [latestProfit] = await db
      .select()
      .from(monthlyProfitsTable)
      .orderBy(desc(monthlyProfitsTable.createdAt))
      .limit(1);

    const currentPrice = latestProfit?.sharePrice ? Number(latestProfit.sharePrice) : 100;

    const result = transactions.map((tx) => {
      const purchasedPrice = Number(tx.pricePerShare);
      const currentValue = tx.shares * currentPrice;
      const purchaseValue = tx.shares * purchasedPrice;
      const gainLoss = currentValue - purchaseValue;
      const gainLossPercent = purchaseValue > 0 ? (gainLoss / purchaseValue) * 100 : 0;

      return {
        id: tx.id,
        shares: tx.shares,
        pricePerShare: purchasedPrice,
        transactionType: tx.transactionType,
        paystackReference: tx.paystackReference ?? null,
        currentPrice,
        currentValue,
        purchaseValue,
        gainLoss,
        gainLossPercent,
        createdAt: tx.createdAt instanceof Date ? tx.createdAt.toISOString() : tx.createdAt,
      };
    });

    logger.info({ userId, count: result.length }, "Fetched user payment history");
    res.json(result);
  } catch (error) {
    logger.error({ error, userId }, "Failed to fetch payment history");
    res.status(500).json({ error: "Failed to fetch payment history" });
  }
});

// POST /payments/initialize — initiate a Paystack payment for share purchase
router.post(
  "/payments/initialize",
  requireAuth,
  paymentRateLimit,
  async (req, res): Promise<void> => {
    const userId = req.userId!;
    const { shares } = req.body;

    if (!shares || shares <= 0 || !Number.isInteger(shares)) {
      res.status(400).json({ error: "A valid positive integer number of shares is required" });
      return;
    }

    try {
      const [soldResult] = await db
        .select({ total: sql`coalesce(sum(shares), 0)` })
        .from(shareTransactionsTable)
        .where(eq(shareTransactionsTable.transactionType, "purchase"));

      const totalSold = Number(soldResult?.total ?? 0);

      if (totalSold + shares > MAX_SHARES_FOR_SALE) {
        res
          .status(400)
          .json({ error: `Only ${MAX_SHARES_FOR_SALE - totalSold} shares remaining for sale` });
        return;
      }

      const [latestProfit] = await db
        .select()
        .from(monthlyProfitsTable)
        .orderBy(desc(monthlyProfitsTable.createdAt))
        .limit(1);

      const currentPrice = latestProfit?.sharePrice ? Number(latestProfit.sharePrice) : 100;

      const [user] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, userId));
      if (!user) {
        res.status(404).json({ error: "User not found" });
        return;
      }

      const amountInKobo = Math.round(shares * currentPrice * 100);

      const initData = await paystackRequest("/transaction/initialize", "POST", {
        email: user.email,
        amount: amountInKobo,
        currency: "NGN",
        metadata: { shares, userId, currentPrice, type: "share_purchase" },
      });

      if (!(initData as any).status) {
        logger.error({ initData, userId }, "Paystack initialization failed");
        res.status(400).json({ error: "Failed to initialize payment with Paystack" });
        return;
      }

      logger.info(
        { userId, shares, currentPrice, reference: (initData as any).data?.reference },
        "Payment initialized"
      );

      res.json({
        authorization_url: (initData as any).data.authorization_url,
        access_code: (initData as any).data.access_code,
        reference: (initData as any).data.reference,
        shares,
        currentPrice,
        totalAmount: shares * currentPrice,
      });
    } catch (error) {
      logger.error({ error, userId }, "Payment initialization error");
      res.status(500).json({ error: "Failed to initialize payment" });
    }
  }
);

// POST /payments/verify — verify Paystack payment and credit shares atomically
router.post(
  "/payments/verify",
  requireAuth,
  paymentRateLimit,
  async (req, res): Promise<void> => {
    const { reference } = req.body;
    const userId = req.userId!;

    if (!reference) {
      res.status(400).json({ error: "Payment reference is required" });
      return;
    }

    try {
      const verifyData: any = await paystackRequest(
        `/transaction/verify/${reference}`,
        "GET"
      );

      if (!verifyData.status || verifyData.data.status !== "success") {
        logger.warn({ reference, userId, paystackStatus: verifyData.data?.status }, "Payment verification failed");
        res.status(400).json({ error: "Payment verification failed" });
        return;
      }

      const metadata = verifyData.data.metadata;
      const shares = Number(metadata.shares);
      const currentPrice = Number(metadata.currentPrice);

      if (!shares || !currentPrice) {
        res.status(400).json({ error: "Invalid payment metadata" });
        return;
      }

      // Check for duplicate (idempotent)
      const [alreadyProcessed] = await db
        .select()
        .from(processedWebhooksTable)
        .where(eq(processedWebhooksTable.reference, reference));

      if (alreadyProcessed) {
        logger.warn({ reference, userId }, "Duplicate payment verification attempt");
        res.status(409).json({ error: "This payment has already been processed" });
        return;
      }

      let tx: any;

      await db.transaction(async (dbTx) => {
        // Mark as processed first (prevents races)
        await dbTx.insert(processedWebhooksTable).values({ reference });

        // Credit the share transaction
        [tx] = await dbTx.insert(shareTransactionsTable).values({
          buyerId: userId,
          sellerId: null,
          shares,
          pricePerShare: String(currentPrice),
          transactionType: "purchase",
          paystackReference: reference,
        }).returning();

        logger.info({ userId, shares, reference, transactionId: tx.id }, "Share transaction created");

        // Update partner shares and set 6-month profit lock if first purchase
        const [partner] = await dbTx
          .select()
          .from(partnersTable)
          .where(eq(partnersTable.userId, userId));

        if (partner) {
          const newShares = partner.sharesOwned + shares;
          const newOwnership = (newShares / TOTAL_SHARES) * 100;

          const updates: Record<string, any> = {
            sharesOwned: newShares,
            ownershipPercentage: String(newOwnership.toFixed(6)),
          };

          // Set 6-month profit lock on first-ever purchase
          if (!partner.profitLockEndsAt) {
            updates.profitLockEndsAt = new Date(Date.now() + SIX_MONTHS_MS);
            logger.info({ userId, lockEndsAt: updates.profitLockEndsAt }, "6-month profit lock set");
          }

          await dbTx
            .update(partnersTable)
            .set(updates)
            .where(eq(partnersTable.id, partner.id));
        }
      });

      logger.info({ userId, shares, reference }, "Payment verified and shares credited");

      // Post-transaction: send emails (non-blocking)
      const [user] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, userId));

      if (user) {
        const totalAmount = shares * currentPrice;
        const date = new Date().toISOString();

        sendPaymentReceipt({
          userEmail: user.email,
          userName: user.fullname,
          shares,
          pricePerShare: currentPrice,
          totalAmount,
          reference,
          date,
        }).catch((e) => logger.error({ e }, "Failed to send receipt email"));

        // Alert admin for large purchases
        sendAdminAlert({
          userName: user.fullname,
          userEmail: user.email,
          shares,
          pricePerShare: currentPrice,
          totalAmount,
          reference,
        }).catch((e) => logger.error({ e }, "Failed to send admin alert"));
      }

      res.json({
        success: true,
        message: "Payment successful. Shares have been credited.",
        sharesCredited: shares,
        transaction: tx,
      });
    } catch (error) {
      logger.error({ error, userId, reference }, "Payment verification error");
      res.status(500).json({ error: "Payment verification failed" });
    }
  }
);

// POST /payments/webhook — Paystack webhook (must not require auth; verify by HMAC)
router.post("/payments/webhook", async (req: Request, res: Response): Promise<void> => {
  try {
    const hash = crypto
      .createHmac("sha512", getPaystackKey())
      .update(JSON.stringify(req.body))
      .digest("hex");

    if (hash !== req.headers["x-paystack-signature"]) {
      logger.warn({ ip: req.ip }, "Invalid Paystack webhook signature");
      res.sendStatus(400);
      return;
    }

    const event = req.body;

    if (event.event === "charge.success") {
      const data = event.data;
      const metadata = data.metadata || {};
      const shares = Number(metadata.shares);
      const currentPrice = Number(metadata.currentPrice);
      const userId = Number(metadata.userId);
      const reference = data.reference;

      if (!shares || !currentPrice || !userId || !reference) {
        logger.warn({ metadata }, "Invalid metadata in Paystack webhook");
        res.sendStatus(200);
        return;
      }

      // Idempotent duplicate check
      const [alreadyProcessed] = await db
        .select()
        .from(processedWebhooksTable)
        .where(eq(processedWebhooksTable.reference, reference));

      if (alreadyProcessed) {
        logger.info({ reference }, "Webhook already processed, skipping");
        res.sendStatus(200);
        return;
      }

      await db.transaction(async (dbTx) => {
        await dbTx.insert(processedWebhooksTable).values({ reference });

        const [tx] = await dbTx.insert(shareTransactionsTable).values({
          buyerId: userId,
          sellerId: null,
          shares,
          pricePerShare: String(currentPrice),
          transactionType: "purchase",
          paystackReference: reference,
        }).returning();

        logger.info({ userId, shares, reference, transactionId: tx.id }, "Webhook: share transaction created");

        const [partner] = await dbTx
          .select()
          .from(partnersTable)
          .where(eq(partnersTable.userId, userId));

        if (partner) {
          const newShares = partner.sharesOwned + shares;
          const newOwnership = (newShares / TOTAL_SHARES) * 100;

          const updates: Record<string, any> = {
            sharesOwned: newShares,
            ownershipPercentage: String(newOwnership.toFixed(6)),
          };

          if (!partner.profitLockEndsAt) {
            updates.profitLockEndsAt = new Date(Date.now() + SIX_MONTHS_MS);
          }

          await dbTx
            .update(partnersTable)
            .set(updates)
            .where(eq(partnersTable.id, partner.id));
        }
      });

      const [user] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, userId));

      if (user) {
        const totalAmount = shares * currentPrice;
        sendPaymentReceipt({
          userEmail: user.email,
          userName: user.fullname,
          shares,
          pricePerShare: currentPrice,
          totalAmount,
          reference,
          date: new Date().toISOString(),
        }).catch((e) => logger.error({ e }, "Webhook: failed to send receipt email"));

        sendAdminAlert({
          userName: user.fullname,
          userEmail: user.email,
          shares,
          pricePerShare: currentPrice,
          totalAmount,
          reference,
        }).catch((e) => logger.error({ e }, "Webhook: failed to send admin alert"));
      }

      logger.info({ userId, shares, reference }, "Webhook: shares credited successfully");
    }

    res.sendStatus(200);
  } catch (error) {
    logger.error({ error }, "Webhook processing error");
    res.sendStatus(200);
  }
});

// GET /payments/receipt/:reference — backend-generated PDF receipt
router.get("/payments/receipt/:reference", requireAuth, async (req, res): Promise<void> => {
  const { reference } = req.params;
  const userId = req.userId!;

  try {
    const [tx] = await db
      .select()
      .from(shareTransactionsTable)
      .where(eq(shareTransactionsTable.paystackReference, reference));

    if (!tx) {
      res.status(404).json({ error: "Receipt not found" });
      return;
    }

    // Only the buyer or admin can download the receipt
    if (tx.buyerId !== userId && req.userRole !== "admin") {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, tx.buyerId!));

    const [partner] = await db
      .select()
      .from(partnersTable)
      .where(eq(partnersTable.userId, tx.buyerId!));

    const pricePerShare = Number(tx.pricePerShare);
    const totalAmount = tx.shares * pricePerShare;
    const ownershipPct = partner
      ? Number(partner.ownershipPercentage).toFixed(4)
      : "0.0000";
    const purchaseDate = tx.createdAt instanceof Date
      ? tx.createdAt.toLocaleDateString("en-NG", { year: "numeric", month: "long", day: "numeric" })
      : String(tx.createdAt);

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>CreatorHub Share Purchase Receipt</title>
  <style>
    body { font-family: Georgia, serif; margin: 40px; color: #111; }
    h1 { text-align: center; font-size: 22px; margin-bottom: 4px; }
    .subtitle { text-align: center; color: #555; font-size: 13px; margin-bottom: 30px; }
    .section { border: 1px solid #ddd; border-radius: 6px; padding: 20px; margin-bottom: 20px; }
    .section h2 { font-size: 15px; margin: 0 0 12px 0; color: #333; text-transform: uppercase; letter-spacing: 1px; }
    table { width: 100%; border-collapse: collapse; }
    td { padding: 8px 4px; font-size: 14px; }
    td:first-child { color: #555; width: 45%; }
    td:last-child { font-weight: bold; }
    .total td { border-top: 2px solid #333; font-size: 16px; }
    .footer { text-align: center; font-size: 12px; color: #888; margin-top: 30px; }
    @media print { button { display: none; } }
  </style>
</head>
<body>
  <h1>CreatorHub Ltd</h1>
  <p class="subtitle">Share Purchase Receipt &nbsp;|&nbsp; Reference: ${reference}</p>

  <div class="section">
    <h2>Shareholder Details</h2>
    <table>
      <tr><td>Name</td><td>${user?.fullname ?? "N/A"}</td></tr>
      <tr><td>Email</td><td>${user?.email ?? "N/A"}</td></tr>
      <tr><td>Ownership %</td><td>${ownershipPct}%</td></tr>
    </table>
  </div>

  <div class="section">
    <h2>Transaction Details</h2>
    <table>
      <tr><td>Purchase Date</td><td>${purchaseDate}</td></tr>
      <tr><td>Transaction ID</td><td>#${tx.id}</td></tr>
      <tr><td>Paystack Reference</td><td>${reference}</td></tr>
      <tr><td>Shares Purchased</td><td>${tx.shares.toLocaleString()}</td></tr>
      <tr><td>Price per Share</td><td>₦${pricePerShare.toFixed(2)}</td></tr>
      <tr class="total"><td>Total Amount Paid</td><td>₦${totalAmount.toLocaleString()}</td></tr>
    </table>
  </div>

  <div class="section">
    <h2>Lock Period Notice</h2>
    <p style="font-size:13px; color:#444; margin:0;">
      As stated in your Shareholder Agreement, no profit distributions will be made during the 
      first 6 months following the platform's official launch. Distributions begin thereafter 
      proportional to your ownership stake.
    </p>
  </div>

  <p class="footer">
    CreatorHub Ltd &nbsp;&middot;&nbsp; This is an official receipt for your records.<br/>
    Please keep this document safe.
  </p>

  <p style="text-align:center; margin-top:20px;">
    <button onclick="window.print()">Print / Save as PDF</button>
  </p>
</body>
</html>`;

    res.setHeader("Content-Type", "text/html");
    res.send(html);

    logger.info({ userId, reference }, "Receipt downloaded");
  } catch (error) {
    logger.error({ error, reference }, "Failed to generate receipt");
    res.status(500).json({ error: "Failed to generate receipt" });
  }
});

export default router;
