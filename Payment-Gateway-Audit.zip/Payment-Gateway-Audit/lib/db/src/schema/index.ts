import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  fullname: text("fullname").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("partner"),
  kycStatus: text("kyc_status").notNull().default("pending"),
  frozen: text("frozen").default("false"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const partnersTable = pgTable("partners", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  sharesOwned: integer("shares_owned").notNull().default(0),
  ownershipPercentage: text("ownership_percentage").notNull().default("0"),
  totalEarnings: text("total_earnings").notNull().default("0"),
  profitLockEndsAt: timestamp("profit_lock_ends_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const shareTransactionsTable = pgTable("share_transactions", {
  id: serial("id").primaryKey(),
  buyerId: integer("buyer_id").references(() => usersTable.id),
  sellerId: integer("seller_id").references(() => usersTable.id),
  shares: integer("shares").notNull(),
  pricePerShare: text("price_per_share").notNull(),
  transactionType: text("transaction_type").notNull(),
  paystackReference: text("paystack_reference").unique(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const monthlyProfitsTable = pgTable("monthly_profits", {
  id: serial("id").primaryKey(),
  month: text("month").notNull(),
  totalProfit: text("total_profit").notNull(),
  distributableProfit: text("distributable_profit").notNull(),
  distributed: boolean("distributed").notNull().default(false),
  currency: text("currency").notNull().default("NGN"),
  sharePrice: text("share_price"),
  priceChangePercent: text("price_change_percent"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const profitDistributionsTable = pgTable("profit_distributions", {
  id: serial("id").primaryKey(),
  partnerId: integer("partner_id").notNull().references(() => partnersTable.id),
  profitMonth: text("profit_month").notNull(),
  amount: text("amount").notNull(),
  status: text("status").notNull().default("pending"),
  currency: text("currency").notNull().default("NGN"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const withdrawalsTable = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  partnerId: integer("partner_id").notNull().references(() => partnersTable.id),
  amount: text("amount").notNull(),
  status: text("status").notNull().default("pending"),
  currency: text("currency").notNull().default("NGN"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const kycDocumentsTable = pgTable("kyc_documents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  documentType: text("document_type").notNull(),
  documentUrl: text("document_url"),
  selfieUrl: text("selfie_url"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const invitationsTable = pgTable("invitations", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  token: text("token").notNull().unique(),
  used: boolean("used").notNull().default(false),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const processedWebhooksTable = pgTable("processed_webhooks", {
  id: serial("id").primaryKey(),
  reference: text("reference").notNull().unique(),
  processedAt: timestamp("processed_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true });
export const insertPartnerSchema = createInsertSchema(partnersTable).omit({ id: true, createdAt: true });
export const insertShareTransactionSchema = createInsertSchema(shareTransactionsTable).omit({ id: true, createdAt: true });
export const insertMonthlyProfitSchema = createInsertSchema(monthlyProfitsTable).omit({ id: true, createdAt: true });
export const insertProfitDistributionSchema = createInsertSchema(profitDistributionsTable).omit({ id: true, createdAt: true });
export const insertWithdrawalSchema = createInsertSchema(withdrawalsTable).omit({ id: true, createdAt: true });
export const insertKycDocumentSchema = createInsertSchema(kycDocumentsTable).omit({ id: true, createdAt: true });
export const insertInvitationSchema = createInsertSchema(invitationsTable).omit({ id: true, createdAt: true });

export type User = typeof usersTable.$inferSelect;
export type Partner = typeof partnersTable.$inferSelect;
export type ShareTransaction = typeof shareTransactionsTable.$inferSelect;
export type MonthlyProfit = typeof monthlyProfitsTable.$inferSelect;
export type ProfitDistribution = typeof profitDistributionsTable.$inferSelect;
export type Withdrawal = typeof withdrawalsTable.$inferSelect;
export type KycDocument = typeof kycDocumentsTable.$inferSelect;
export type Invitation = typeof invitationsTable.$inferSelect;
